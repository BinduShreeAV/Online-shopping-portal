<?php
include('dbconnection.php');
error_reporting(0);
$errors=array();

if (isset($_POST['Login'])) {
  $name = isset($_POST['name'])? $_POST['name']:' ';
 $password = isset($_POST['password']) ? $_POST['password']:' ';

 if (empty($name)) {
  array_push($errors, "User name is required");
}

if (empty($password)) {
  array_push($errors, "Password is required");
}

if (count($errors) == 0) {
  $password = $password;
  	$query = "SELECT * FROM admin WHERE name ='$name' AND password='$password'";
  	$results = mysqli_query($conn,$query);
	$r=mysqli_fetch_row($results);
	
	if($r)
	{session_start(); 
  	 $_SESSION['alogin'] = $_POST['name'];
	 echo "<script type='text/javascript'> document.location = 'adminhome.php'; </script>";
	 
	}
	else{
 	array_push($errors, "Wrong loginid or password"); 	  
  	}
  }
}




?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Login Page</title>

<style>
@import "https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css";
body{
margin: 0;
padding: 0;

  /*background: url(images/admin.jpg);*/
  background-size: cover;
  background-position:center;
  height:100vh;
  width:100%;
font-family: sans-serif;
text-align:center;
}

.box{
	
  padding: 80px;
  margin: auto;
	border: 1px solid rgba(0,0,0,0.01);
}

input[type=text],input[type=email],input[type=password]
{
width: 90%;
padding: 12px 20px;
margin: 8px 0;
display: inline-block;
border: 1px solid #ccc;
box-sizing: border-box;
}

input[type=submit]{
background-color: #2b88d8; /*#4CAF50;*/
color: white;
padding: 14px 20px;
    margin: 8px 0;
border: none;
font-family: halvetica;
font-size:100%;
cursor: pointer;
width: 60%;
font-weight: 600;
border-radius: 8px;
}
input[type=submit]:hover {

box-shadow: inset 4px 4px 6px -1px rgba(0,0,0,0.2),
						inset -4px -4px 6px -1px rgba(255,255,255,0.7),
						-0.5px -0.5px 0px rgba(255,255,255,1),
						0.5px  0.5px 0px rgba(0,0,0,0.15),
						0px 12px 10px -10px rgba(0,0,0,0.05);

						border: 1px solid rgba(0,0,0,0.01);
            font-weight: 600;


}

button
{
	width:20%;
	background-color: #2b88d8;
	color:white;
	border: 1px outset grey;
    border-radius: 8px;
	padding: 3px 3px;
	cursor: pointer;
	font-size: 20px;
	z-index:1;
	font-weight: 600;
	margin-right: 1000px;
	margin-top: 20px;
}

button:hover 
{
    box-shadow: inset 4px 4px 6px -1px rgba(0,0,0,0.2),
						inset -4px -4px 6px -1px rgba(255,255,255,0.7),
						-0.5px -0.5px 0px rgba(255,255,255,1),
						0.5px  0.5px 0px rgba(0,0,0,0.15),
						0px 12px 10px -10px rgba(0,0,0,0.05);

						border: 1px solid rgba(0,0,0,0.01);
            font-weight: 600;
}

</style>



</head>

<body>
<a href="index.php" >
    <button type="button" class="button">Go Back</button> <br/>
</a>

<center>
<form action="adminlogin.php" name="admin login" class="box" method="post">

  <div  style="border:4px ridge #ffff; display:flex; height:400px; width:350px; background-color:#ffff; opacity:0.8; border-radius:15px;align-items:center; justify-content:center;">
  
  <table align="center"><tr><th colspan="2" align="center" height="25px" >
  
  <font size="6">Admin Login</font>
  <p> <small><i> <b> Please fill up the login details.</b></small></i> </p> <br>
  <?php include('errors.php'); ?>
</th></tr>
  
  <tr><td align="left" >
        <b>Name:</b><br/>
	<input type="text" name="name" required="required" size="40"  placeholder="Enter user name" autofocus/></td></tr>

  
	<tr><td align="left" >
	 <b> Password:</b><br/>
	<input type="password" name="password" required="required" size="40"  placeholder="Enter Password"  title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"
    pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"/></td></tr>
	
	<tr><td colspan="2" align="center">
	<input type="submit" value="Login" name="Login"  />
	<br/></td></tr></table>
	

	</div>
	</center>
  
</form>
</body>
</html>