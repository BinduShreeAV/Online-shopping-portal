<?php
session_start();
error_reporting(0);
include('dbconnection.php');

// customer registration code
$name = "";
$mobile_no = "";
$email_id = "";
$password = "";
$confirm_password="";

if(isset($_POST['register']))
{
	$name = isset($_POST['name'])? $_POST['name']:' ';
	$mobile_no = isset($_POST['mobile_no'])? $_POST['mobile_no']:' ';
	$email_id = isset($_POST['email_id'])? $_POST['email_id']:' ';
	$password = md5( isset($_POST['password'])? $_POST['password']:' ');
	$confirm_password = md5(isset($_POST['confirm_password'])? $_POST['confirm_password']:' ');

	if($password != $confirm_password){
		array_push($errors,"Passwords do not match.");
		 echo "<script type='text/javascript'> alert('Password and confirm password do not match !'); </script>";
		}
	
	

	$user_check_query = "SELECT * FROM user WHERE email_id='$email_id'";

$query = mysqli_query($conn , $user_check_query);

if (mysqli_num_rows($query) > 0) 
{
  // output data of each row
  $row = mysqli_fetch_assoc($query);
  
  if($email_id==$row['email_id']) 
  {
	  array_push($errors,"Email Id already exists");
	  echo "<script type='text/javascript'> alert('Email ID already exists !'); </script>";
  }
}

if(count($errors) == 0)
	 {
    echo "yes";
		 
	  $q = "INSERT INTO user (name,mobile_no,email_id,password) 
    VALUES('$name','$mobile_no','$email_id','$password')";
   
	 	mysqli_query($conn,$q); 
    
   
		 echo "<script type='text/javascript'> alert('You are now registered successfully.Please login to continue'); </script>";
     
     echo "<script type='text/javascript'> document.location = 'login.php'; </script>";
    

  }   

}
/////  Customer Login Page code

elseif(isset($_POST['login']))  {
   $email_id = $_POST['email_id'];
   $password = md5($_POST['password']);


   $qu = "SELECT * FROM user WHERE email_id='$email_id' AND password='$password'";
   $que = mysqli_query($conn , $qu);
   $num = mysqli_fetch_array($que);
   if($num > 0)
   {
	   $extra="index.php";
	   $_SESSION['login'] = $_POST['email_id'];
	   $_SESSION['id'] = $num['user_id'];
	   $_SESSION['username'] = $num['name'];
	  // $_SESSION['contact1'] = $num['mobile_no'];
	   $host = $_SERVER['HTTP_HOST'];
	   $uri = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
	   header("location:http://$host$uri/$extra");
	   exit();
   }
   else
   {
	   $extra="login.php";
	   $email_id = $_POST['email_id'];

	   $host = $_SERVER['HTTP_HOST'];
	   $uri = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
	   header("location:http://$host$uri/$extra");
	   $_SESSION['errmsg'] = "Inavlid Email Id or Password";
	   exit();

   }
}
?>

<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Login || HH Stores</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- favicon -->
        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
		<!-- all css here -->
		<!-- style css -->
		<link rel="stylesheet" href="style.css">

		<!-- modernizr js -->
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>

		
    </head>
    <body>
        <!-- header section start -->
		<header>
			<div class="header-top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
						<div class="left floatleft">
								<ul>
								<?php 
								if(isset($_SESSION['login']))
                                {   ?>
				                <li>
								<i class="icon fa fa-user"></i>
								<a href="#" style="color:white;"><b>Welcome <?php echo htmlentities($_SESSION['username']);?></b></a>
								</li>
				                <?php } ?>


								    <li>
										<i class="fa fa-user"></i> 
										<a href="my-account.php"><b>Account</b></a>
									</li>
									<li>
									<i class="icon fa fa-heart"></i>
									<a href="wishlist.php"><b>Wishlist</b></a>
	                             	</li>
									<?php
									if(isset($_SESSION['login'] ) == 0)
									{?>
                                    <li>
									<i class="icon fa fa-sign-in"></i>
									<a href="login.php"><b>Login</b></a></li>
									<?php }
                                    else{ ?>
				                    <li>
									<i class="icon fa fa-sign-out"></i>
									<a href="logout.php"><b>Logout</b></a></li>
				                    <?php } ?>	

								</ul>
							</div>	
						</div>
					</div>
				</div>
			</div>
			<div id="sticky-menu" class="header-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 header-bottom-bg">
							<div class="logo floatleft">
							<a href="index.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
							</div>
							<div class="mainmenu text-center floatleft">
								<nav>
									<ul>
										<li><a href="index.php">Home</a></li>
										<li>
											<a href="shop.php">products</a>
										</li>
										
										<li><a href="#">Pages</a>
											<ul>
												
												<li>
													<a href="my-account.php">My account</a>
												</li>
												<li>
													<a href="wishlist.php">Wishlist</a>
												</li>
												<li>											
													<a href="shop.php">Shop</a>
												</li>
												
									
											</ul>
										</li>
										<li>
		                              <a href="contact.php">contact</a>
	                                </li>
									</ul>
								</nav>
							</div>
							<!-- mobile menu start -->
							
							<!-- mobile menu end -->
							
						</div>
					</div>
				</div>
			</div>
		</header>
        <!-- header section end -->
		<!-- page banner area start -->
		<div class="page-banner">
			<img src="img/slider/33.jpg" alt="Page Banner" />
		</div>
		<!-- page banner area end -->
		<!-- cart page content section start -->
		<section class="login-page section-padding">
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="row">
							<div class="single-check">
								<form action="login.php" method="post">
									<div class="single-input p-bottom50 clearfix">
										<div class="col-xs-12">
											<div class="check-title">
												<h3>Login</h3>
												<p>If you have an account with us, Please log in!</p>
											</div>
										</div>
										<span style="color:red;" >
<?php
echo htmlentities($_SESSION['errmsg']);
?>
<?php
echo htmlentities($_SESSION['errmsg']="");
?>
	</span>
										<div class="col-xs-12">
											<label>Email:</label>
											<div class="input-text">
												<input type="email" name="email_id" required />
											</div>
										</div>
										<div class="col-xs-12">
											<label>Password:</label>
											<div class="input-text">
												<input type="password" name="password" required />
											</div>
										</div>
										<!--<div class="col-xs-12">
											<div class="forget">
												<a href="#">Forget your password?</a>
											</div>
										</div>-->
										<div class="col-xs-12">
											<div class="submit-text">
												<input type="submit" name="login" value="Login">
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="single-input p-bottom50 clearfix">						
							<form action="login.php"  method="post">
							<?php include('errors.php')?>
								<div class="row">
									<div class="col-xs-12">
										<div class="check-title">
											<h3>New Customer</h3>
										</div>
									</div>
									<div class="col-xs-12">
										<label>Full Name:</label>
										<div class="input-text">
											<input type="text" name="name" required />
										</div>
									</div>
									<div class="col-xs-12">
										<label>Mobile Number:</label>
										<div class="input-text">
											<input type="text" name="mobile_no" pattern="[0-9]{10}"  title="Input a 10 digit valid number" required />
										</div>
									</div>
									<div class="col-xs-12">
										<label>Email:</label>
										<div class="input-text">
											<input type="email" name="email_id" required/>
										</div>
									</div>
									<div class="col-sm-6">
										<label>Password:</label>
										<div class="input-text">
											<input type="password" name="password" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"
											pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"  required
																					
											/>
										</div>
									</div>
									<div class="col-sm-6">
										<label>Confirm Password:</label>
										<div class="input-text">
											<input type="password" name="confirm_password" required />
										</div>
									</div>
									<div class="col-xs-12">
	
										<div class="submit-text">
											<input type="submit" name="register" value="Register">
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- cart page content section end -->
		<!-- footer section start -->
		<footer>
			<div class="footer-logo-text padding-close">
				<div class="container text-center">
				<a href="index.php">
									<img src="img/log2.png" alt="Rideo" />
								</a>
					<p>Contact Us:   </p>
				<p>	<i class="fa fa-envelope"> </i> happilyhandmadeonlineportal@gmail.com</p>
				</div>
			</div>
			<!-- footer top start -->
			<!-- footer top end -->
			<!-- footer bottom start -->
			<div class="footer-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
						<div class="left floatleft">
								<p>Copyright &copy; 2021 By <a href="http://localhost/hh/index.php">HH Stores</a></p>
							</div>
							<!--<div class="right mayment-card floatright">
								<ul>
									<li>
										<a href="#"><img src="img/footer/v1.png" alt="Payment Card" /></a>
									</li>
									<li>
										<a href="#"><img src="img/footer/v2.png" alt="Payment Card" /></a>
									</li>
									<li>
										<a href="#"><img src="img/footer/v3.png" alt="Payment Card" /></a>
									</li>
									<li>
										<a href="#"><img src="img/footer/v4.png" alt="Payment Card" /></a>
									</li>
								</ul>
							</div>-->
						</div>
					</div>
				</div>
			</div>
			<!-- footer bottom end -->
		</footer>
		<!-- footer section end -->
		
		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.3.min.js"></script>
		<!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
		<!-- camera slider JS -->
        <script src="js/camera.min.js"></script>
		<!-- jquery.easing js -->
        <script src="js/jquery.easing.1.3.js"></script>
		<!-- slick slider js -->
        <script src="js/slick.min.js"></script>
		<!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
		<!-- magnific-popup js -->
        <script src="js/magnific-popup.min.js"></script>
		<!-- countdown js -->
        <!--<script src="js/countdown.js"></script>-->
		<!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
		<!-- plugins js -->
        <script src="js/plugins.js"></script>
		<!-- main js -->
        <script src="js/main.js"></script>
    </body>
</html>
