<?php
session_start();
//error_reporting(0);
include('dbconnection.php');
$oid=$_GET['id'];
?>




<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Order History || HH Stores</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- favicon -->
     <!--  <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">-->
        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
		<!-- all css here -->
		<!-- style css -->
		<link rel="stylesheet" href="style.css">
		<!-- modernizr js -->
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
        

        <!-- header section start -->
		<header>
			<div class="header-top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="left floatleft">
								<ul>
									<?php 
								if(isset($_SESSION['login']))
                                {   ?>
				                <li>
								<i class="icon fa fa-user"></i>
								<a href="#" style="color:white;"><b>Welcome <?php echo htmlentities($_SESSION['username']);?></b></a>
								</li>
								<?php } ?>	
								
								<li>
										<i class="fa fa-user"></i> 
										<a href="my-account.php"><b>Account</b></a>
									</li>
									<li>
									<i class="icon fa fa-heart"></i>
									<a href="wishlist.php"><b>Wishlist</b></a>
									 </li>
									 <?php
									if(isset($_SESSION['login'] ) == 0)
									{?>
                                    <li>
									<i class="icon fa fa-sign-in"></i>
									<a href="login.php"><b>Login</b></a></li>
									<?php }
                                    else{ ?>
				                    <li>
									<i class="icon fa fa-sign-out"></i>
									<a href="logout.php"><b>Logout</b></a></li>
				                    <?php } ?>	
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div id="sticky-menu" class="header-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 header-bottom-bg">
							<div class="logo floatleft">
								<a href="index.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
							</div>
							<div class="mainmenu text-center floatleft">
								<nav>
									<ul>
										<li><a href="index.php">Home</a></li>
										<li>
											<a href="shop.php">products</a>
										</li>
										
										
										</li>
										<li><a href="#">Pages</a>
											<ul>
												
												<li>
													<a href="my-account.php">My account</a>
												</li>
												
												<li>
													<a href="wishlist.php">Wishlist</a>
												</li>
												<li>
													<a href="shop.php">Shop</a>
												</li>												
													
											</ul>
										</li>
										<li>
											<a href="contact.php">contact</a>
										</li>
									</ul>
								</nav>
							</div>
							<!-- mobile menu start -->
							
							<!-- mobile menu end -->
							<?php include('cart-content.php');?>
						</div>
					</div>
				</div>
			</div>
		</header>
        <!-- header section end -->
		<!-- page banner area start -->
		<div class="page-banner">
			<img src="img/slider/333.jpg" alt="Page Banner" />
		</div>
		<!-- page banner area end -->
		<!-- cart page content section start -->
		<form name="cart" method="get" enctype="multipart/form-data" action="order-history.php">
		<section class="cart-page section-padding">
			<div class="container">
				<div class="row">
					<div class="col-xs-15">
                      
						<div class="table-responsive table-one margin-minus section-padding-bottom">
						
							<table class="spacing-table text-center">
								<thead>
									<tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
									<th>Price Per Unit</th>
									<th>Shipping Charges</th>
									
									</tr>
								</thead>

								<tbody>
								<?php
							 // $result =  mysqli_query($conn, "SELECT * FROM orders WHERE orderdate='$oid' AND userid='".$_SESSION['id']."'");
							  $result =  mysqli_query($conn, "SELECT products.productprice as productprice, products.shippingcharges as shippingcharges,products.productimage as productimage,products.productname as productname,orders.amount_paid as amount_paid, orders.quantity as quantity FROM orders JOIN products on products.id=orders.productid WHERE orderdate='$oid' AND userid='".$_SESSION['id']."'");
							  
                              while($row=mysqli_fetch_array($result))
								{?>
	                           
									<tr>
                                     
										<td class="td-img text-left"><?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:240px; height:190px;">';?>
										&emsp;&emsp;&emsp;&emsp;&emsp;<?php echo $row['productname']; ?>
									    </td>
                                        <td><span class="cart-sub-total-price"><?php echo $row['quantity']; ?></span></td>
										<td><span class="cart-sub-total-price"><?php echo $row['productprice']; ?></span></td>
										<td><span class="cart-sub-total-price"><?php echo $row['shippingcharges']; ?></span></td>
									</tr>
									
									
							
								
								</tbody>
							
								<?php } 
				                    ?>	
							</table>
							

						
					</div>
					
				</div>

               
                    <div class="row">
					    <div class="col-sm-4">
                        <?php
                              $result =  mysqli_query($conn, "SELECT DISTINCT amount_paid, paymentmethod FROM orders WHERE orderdate='$oid' AND userid='".$_SESSION['id']."'");
                              while($row=mysqli_fetch_array($result))
								{?>
						   <div class="estimate-text responsive">
							   <div class="subtotal clearfix">
								   <p>Grandtotal: <span class="floatright">Rs. <?php echo $row['amount_paid']; ".00"; ?></span></p>
								   <p>Payment Mode: <span class="floatright"><?php echo $row['paymentmethod'];  ?></span></p>
								   <div class="order-btn">
								<a class="btn-style" href="javascript:history.back()">Go Back</a>
							</div>	
							   </div>	
                            </div>
                            <?php } 
				                    ?>	
					    </div>
				    </div>
			</div>



				
			</div>
		</section>
		</form>
		
		<footer>
			
			
			
			<div class="footer-logo-text">
				<div class="container text-center">
					<a href="index.php"><img src="img/log2.png" alt="Logo" /></a>
					<p>Contact Us:   </p>
				<p>	<i class="fa fa-envelope"> </i> happilyhandmadeonlineportal@gmail.com</p>
					
				</div>
			</div>
			<!-- footer top start -->
			
			<!-- footer top end -->
			<!-- footer bottom start -->
			<div class="footer-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="left floatleft">
							<p>Copyright &copy; 2021 By <a href="http://localhost/hh/index.php">HH Stores</a></p>
								
						</div>
							<div class="right mayment-card floatright">
								<ul>
									
									<li>
										<a href="#"><img src="img/footer/v6.png" alt="Payment Card" /></a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- footer bottom end -->
		</footer>
		<!-- footer section end -->
		
		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.3.min.js"></script>
		<!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
		<!-- camera slider JS -->
        <script src="js/camera.min.js"></script>
		<!-- jquery.easing js -->
        <script src="js/jquery.easing.1.3.js"></script>
		<!-- slick slider js -->
        <script src="js/slick.min.js"></script>
		<!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
		<!-- magnific-popup js -->
        <script src="js/magnific-popup.min.js"></script>
		<!-- countdown js -->
      <!--  <script src="js/countdown.js"></script>-->
		<!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
		<!-- plugins js -->
        <script src="js/plugins.js"></script>
		<!-- main js -->
        <script src="js/main.js"></script>
		
		<!-- Google Map JS -->
		<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA_Agsvf36du-7l_mp8iu1a-rXoKcWfs2I"> </script>
		<!-- Custom map-script js -->
        <script src="js/map-script.js"></script>
    </body>
</html>

