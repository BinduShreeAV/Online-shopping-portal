<?php
session_start();
include('dbconnection.php');




$pid=intval($_GET['id']);

	$product = mysqli_query($conn,"SELECT products.*,category.categoryname as catname,category.id as cid from products join category on category.id=products.category where products.id='$pid'");	
$cols = mysqli_fetch_assoc($product);



?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UFT-8">
  <title>HH Stores</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
    <style>
  	   @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');
		 <?php include('adminstyle.css'); ?>    
		 .add-form{
			 background-color: white;
			 padding: 40px;
			 margin: auto;
			 border: 1px solid rgba(0,0,0,0.01);

		 }
		 .form-box{
			 color:#8390A2;
			 font-weight:600;
			 font-size: 17px;
			 
		 }
		
		 .form1-box{
			color:#8390A2;
			font-weight:600;
			margin-top: -30px;
			font-size: 17px;
		 }	
         .cat-box{
			 line-height: 40px;
			 padding: 0 84.5px;	 
		 }			
         .p1-box{
			color:#8390A2;
			font-weight:600;
			font-size: 17px;
			margin-left: 180px;
			margin-top: -30px;
		 }	
		 .p2-box{
			color:#8390A2;
			font-weight:600;
			font-size: 17px;
			margin-top:25px;
		 }
         .p3-box{
			color:#8390A2;
			font-weight:600;
			font-size: 17px;
			margin-left: 180px;
			margin-top: 25px;
		 }	
         .p9-box{
			margin-top: 50px; 
			
		 }
		 .add-box{
			 color:white;
			 background-color: #2b88d8;
			 font-weight: 600;
			 letter-spacing: 2px;
			 font-size:15px;
			 box-shadow: 6px 6px 10px -1px rgba(0,0,0,0.50),
						-6px -6px 10px -1px rgba(255,255,255,0.90);
						
			 border: none;
			 height: 40px;
			 width: 200px;
			 border-radius: 4px;
		 }
		 .add-box:hover{
			box-shadow: inset 4px 4px 6px -1px rgba(0,0,0,0.2),
						inset -4px -4px 6px -1px rgba(255,255,255,0.7),
						-0.5px -0.5px 0px rgba(255,255,255,1),
						0.5px  0.5px 0px rgba(0,0,0,0.15),
						0px 12px 10px -10px rgba(0,0,0,0.05);

						border: 1px solid rgba(0,0,0,0.01);
						
   
		 }
		 .p5-box{	
			font-weight:600;
			margin-left: 168px;
			margin-top: 40px;
		 }
		 .image1-box{
			display: flex;
			justify-content: center;
			background:#f1f5f9;
			height: 75px;
			weight: 75px;
			margin: 0 15px;
			border-radius: 8px;
			align-items: center;
			text-decoration: none;
			box-shadow: 6px 6px 10px -1px rgba(0,0,0,0.15),
			            -6px -6px 10px -1px rgba(255,255,255,0.7);

		}
		.image1-box:hover{
			box-shadow: inset 4px 4px 6px -1px rgba(0,0,0,0.2),
						inset -4px -4px 6px -1px rgba(255,255,255,0.7),
						-0.5px -0.5px 0px rgba(255,255,255,1),
						0.5px  0.5px 0px rgba(0,0,0,0.15),
						0px 12px 10px -10px rgba(0,0,0,0.05);

						border: 1px solid rgba(0,0,0,0.01);

		}
		.image1-box i {
			font-size: 35px;
			color: orange;
			transition: 0.3s;
		}
		.image1-box:hover i{
			font-size: 45px;
		}
		
  </style>
</head>
<body>
	<div class="sidebar">
		<div class="sidebar-brand">
		<a href="adminhome.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
		</div>
		<br>
		<div class="sidebar-menu">
			<ul>
				<li>
					<a href="adminhome.php"><span class="fas fa-igloo"></span>
						<span>Dashboard</span></a>
				</li>
				<li>
					<a href="addproducts.php" ><span class="fas fa-plus-square"></span>
						<span>Add Products</span></a>
				</li>
				
				<li>
					<a href="manageproducts.php" class="active"><span class="fas fa-cogs"></span>
						<span>Manage Products</span></a>
				</li>
				<li>
					<a href="viewcustomers.php"><span class="fas fa-users"></span>
						<span>View Customers</span></a>
				</li>
				<li>
					<a href="viewfeedbacks.php"><span class="fas fa-comments"></span>
						<span>View Feedbacks</span></a>
				</li>
				<li class="item">
					<a href="" class="order-btn"><span class="fas fa-tasks"></span>
						<span>Order Management <i class="fas fa-chevron-down drop-down"></i></span></a>
						<ul class="sub-menu">
                        <li>
                        <a href="todays-order.php"><span class="fas fa-clipboard-list"></span>
						<span>Today's Order</span></a>   
                        </li>
                        <li>
                        <a href="pending-orders.php"><span class="fas fa-clock"></span>
						<span>Pending Orders</span></a>   
						</li>
						<li>
						<a href="outfordelivery-orders.php"><span class="fas fa-clipboard-check"></span>
						<span>Out For Delivery Orders</span></a>   
                        </li>
                        <li>
                        <a href="delivered-orders.php"><span class="fas fa-clipboard-check"></span>
						<span>Delivered Orders</span></a>   
                        </li>
                        </ul>                    
				</li>
				<li>
					<a href="logout1.php"><span class="fas fa-sign-out-alt"></span>
						<span>Sign Out</span></a>
				</li>
			</ul>
		</div>
	</div>
	<div class="main-content">
		<header>
			<h2>
				Add Product Properties
			</h2>
			<div>
				
                <a class="user-wrapper" href="adminhome.php"><span class="fas fa-user-shield"></span>
						<span><h3>Admin</h3></span></a>

			</div>
		</header>
	
<main>
<form id="addproduct" class="add-form" method="post" action="retrieve1.php" enctype="multipart/form-data">

<table>
   <tr> <td>
   <div class="form1-box">
        <label for="category">Category</label><br>
            <select class="cat-box" name="category" id="category" onChange="getSubcat(this.value);" required>
                      <option value=" <?php echo htmlentities($cols['category']);?> " selected readonly> <?php echo htmlentities($cols['catname']);?> </option>
					  
            </select>
    </div>
	</td>
    <td>
	<div class="p1-box">
	    <label for="Product Name">Product Name</label><br>
        <select class="" name="proid" id="category" onChange="getSubcat(this.value);" required>
                      <option value=" <?php echo htmlentities($cols['id']);?> " selected readonly> <?php echo htmlentities($cols['productname']);?> </option>
					  
            </select>
		
    </div>
</td>
</tr>

<tr>
<td>
<div class="p2-box">
	    <label for="Product Owner">Product Property</label><br>
		<input id="productowner" name="property" placeholder="Enter Product Property" type="text" class="owner-box" required/>
	</div>
</td>

<td>
	<div class="p3-box">
	    <label for="Product Price">Product Price</label><br>
		<input id="productprice" name="productprice" placeholder="Enter Product Price" type="text" class="price-box" required/>
	</div>
</td>
</tr>

<tr>
<td>
	<div class="p2-box">
	    <label for="Product Name">Customized Product Name</label><br>
		<input id="customizedproductname" name="customizedproductname" placeholder="Enter Customized product name" type="text" class="price-box" required/>
	
    </div>
</td>
<td>
	<div class="p3-box">
        <div class="image1-box">
            <i class="fas fa-cloud-upload-alt tm-upload-icon"
                onclick="document.getElementById('fileInput').click();"></i>
        </div><br><br> 
            <div class="image2-box">
                <input id="image" name="productimage" type="file" />                  
        </div>
    </div>
</td>
</tr>

<tr>
<td>
	<div class="p9-box">
		<input id="addproducts" name="submit" type="submit" value="ADD" class="add-box" required/>
		<input type="hidden" name="pid" value="<?php echo htmlentities($pid);?>"/>

	</div>
	</td>

</tr>

</table>
</form>
</main>
</div>
</body>
</html>
