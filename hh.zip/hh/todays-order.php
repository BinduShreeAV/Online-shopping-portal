<?php
session_start();
include('dbconnection.php');

if(strlen($_SESSION['alogin'])== 0)
    {   
header('location:adminlogin.php');
}
else
{
	date_default_timezone_set('Asia/Kolkata');// change according timezone
	$currentTime = date( 'd-m-Y h:i:s A', time () );
	
    
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UFT-8">
  <title>HH Stores</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
    <style>
  	   @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');
		 <?php include('adminstyle.css'); ?>   
		 .manage-form{
			 background-color: white;
		 }

         .x{
			 position: absolute;
			 z-index:2;
			 width: 10%;
			 height: 40px;
			 background:#fafafa;
			 text-align: center;
			 border-collapse: collapse;
			 border-spacing: 0;
			 border-radius: 12px 12px 0 0;
			 overflow: hidden;
			 

         }

         th,td{
			 padding: 7px 13px;
		 }

		 th{
			 background: orange;
			 color: #fafafa;
			 font-size: 17px;
		 }

		 tr:nth-child(odd){
			 background-color: #eeeeee;
		 }
		 .am{
			background-color:#2b88d8;
			 color: white;
			 border: none;
			 letter-spacing: 1.5px;	 
			 padding:  4px;
		}
		.am:hover{
			background-color: rgba(38, 166, 91, 1);
			color: white;
			font-weight:500;
		}	
		
  </style>
</head>
<body>
	<div class="sidebar">
		<div class="sidebar-brand">
		<a href="adminhome.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
		</div>
		<br>
		<div class="sidebar-menu">
			<ul>
				<li>
					<a href="adminhome.php"><span class="fas fa-igloo"></span>
						<span>Dashboard</span></a>
				</li>
				<li>
					<a href="addproducts.php" ><span class="fas fa-plus-square"></span>
						<span>Add Products</span></a>
				</li>
				
				<li>
					<a href="manageproducts.php"><span class="fas fa-cogs"></span>
						<span>Manage Products</span></a>
				</li>
				<li>
					<a href="viewcustomers.php"><span class="fas fa-users"></span>
						<span>View Customers</span></a>
				</li>
				<li>
					<a href="viewfeedbacks.php"><span class="fas fa-comments"></span>
						<span>View Feedbacks</span></a>
				</li>
				<li class="item" >
                
					<a href="" class="order-btn" ><span class="fas fa-tasks"></span>
						<span >Order Management <i class="fas fa-chevron-down drop-down"></i></span></a>
						<ul class="sub-menu">
                        <li>
                        <a href="todays-order.php"><span class="fas fa-clipboard-list"></span>
						<span>Today's Order</span></a>   
                        </li>
                        <li>
                        <a href="pending-orders.php"><span class="fas fa-clock"></span>
						<span>Pending Orders</span></a>   
						</li>
						<li>
						<a href="outfordelivery-orders.php"><span class="fas fa-clipboard-check"></span>
						<span>Out For Delivery Orders</span></a>   
                        </li>
                        <li>
                        <a href="delivered-orders.php"><span class="fas fa-clipboard-check"></span>
						<span>Delivered Orders</span></a>   
                        </li>
                        </ul>                    
				</li>
				<li>
					<a href="logout1.php"><span class="fas fa-sign-out-alt"></span>
						<span>Sign Out</span></a>
				</li>
			</ul>
		</div>
	</div>
	<div class="main-content">
		<header>
			<h2>
				Today's Orders
			</h2>
			<div>
				
                <a class="user-wrapper" href="adminhome.php"><span class="fas fa-user-shield"></span>
						<span><h3>Admin</h3></span></a>

			</div>
		</header>
	
<main>
<form id="todays-orders" class="manage-form" method="post" action="todays-orders.php">
   <table class="x">
   <tr>
   
   <th>Name</th>
   <th>Email & Contact No</th>
   <th>Shipping Address/City/State/Pincode</th>
   <th>Amount</th>
   <th>Order Date</th>
   <th>Order Status</th>
   <th>View Details</th>
   <th>Update Status</th>
   </tr>
 
 <tbody>
 <?php 
 $f1="00:00:00";
$from=date('Y-m-d')." ".$f1;
$t1="23:59:59";
$to=date('Y-m-d')." ".$t1;
$query=mysqli_query($conn,"SELECT  DISTINCT amount_paid ,orderdate,orderstatus, user.name as username,user.email_id as useremail,user.mobile_no as usercontact,user.shippingaddress as shippingaddress,user.shippingcity as shippingcity,user.shippingstate as shippingstate,user.shippingpincode as shippingpincode from orders join user on  orders.userid=user.user_id  where orders.orderdate Between '$from' and '$to' AND orders.paymentmethod!='NULL'");
$cnt=1;
while($row=mysqli_fetch_array($query))
{
?>	
   <tr>
  
     <td><?php echo htmlentities($row['username']);?></td>
     <td><?php echo htmlentities($row['useremail']);?>
     <?php echo htmlentities($row['usercontact']);?></td>
     <td><?php echo htmlentities($row['shippingaddress'].",".$row['shippingcity'].",".$row['shippingstate']."-".$row['shippingpincode']);?></td>
     <td><?php echo htmlentities($row['amount_paid']);?></td>
	 <td><?php echo htmlentities($row['orderdate']);?></td>   
	 <td><?php echo htmlentities($row['orderstatus']);?></td> 
	 <td><a class="am" href="order-history1.php?id=<?php echo $row['orderdate'];?>">View</a></td>
     <td><a class="am" href="order-status.php?id=<?php echo $row['orderdate'];?>">Status</a></td>

    </td>
  </tr>
  <?php  } ?>							
	
</tbody>
   


   
</table>
</form>
</main>
</div>
</body>
</html>
<?php } ?>