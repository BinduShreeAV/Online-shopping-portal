<?php 

 if(isset($_Get['action'])){
		if(!empty($_SESSION['cart'])){
		foreach($_POST['quantity'] as $key => $val){
			if($val==0){
				unset($_SESSION['cart'][$key]);
			}else{
				$_SESSION['cart'][$key]['quantity']=$val;
			}
		}
		}
	}
?>


<form action="" method="" enctype="multipart/form-data">
<div class="cart-menu-area floatright">
<?php
    if(!empty($_SESSION['cart'])){
	?>
	<ul>
	<li>
    <a href="#" class="dropdown-toggle lnk-cart" data-toggle="dropdown">
    <i class="pe-7s-shopbag"></i> 
    <div class="basket-item-count" >
    <span class="count">
    <?php echo $_SESSION['qnty'];?> 
    </span>
    </div>
    </a>
    
       <ul class="cart-menu">
       <?php
         $sql = "SELECT * FROM products WHERE id IN(";
		foreach($_SESSION['cart'] as $id => $value){
        $sql .=$id. ",";
        }
        $sql=substr($sql,0,-1) . ") ORDER BY id ASC";
		$query = mysqli_query($conn,$sql);
		$totalprice=0;
        $totalqunty=0;
        if(!empty($query)){
			while($row = mysqli_fetch_array($query)){
				$quantity=$_SESSION['cart'][$row['id']]['quantity'];
				$subtotal= $_SESSION['cart'][$row['id']]['quantity']*$row['productprice']+$row['shippingcharges'];
				$totalprice += $subtotal;
				$_SESSION['qnty']=$totalqunty+=$quantity;

	?>
		<li>
            <a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
			<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:85px; height:81px;">';?></a>
			<div class="cart-menu-title">
            <a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>" >
            <h5><?php echo $row['productname']?></h5>
            </a>
			<span>
            <div class="price">Rs.<?php echo ($row['productprice']+$row['shippingcharges']); ?> * <?php echo $_SESSION['cart'][$row['id']]['quantity']; ?></div>			
            </span>
		    </div>
    </li>
    <?php } }?>
	<li class="cart-menu-btn">
	<a href="cart.php">view cart</a>
	</li>
	</ul>
    </li>
    
    </ul>
    
</div>
            
<?php } else { ?>
    <div class="cart-menu-area floatright">
	<ul>
	<li>
    <a href="#" class="dropdown-toggle lnk-cart" data-toggle="dropdown">
    <i class="pe-7s-shopbag"></i> 
    <span>0</span>
    </a>
        
       <ul class="cart-menu">
		<li>
        <div class="col-xs-12">
			<p style="color:black;font-size:18px;font-weight:500px;"><strong>Your Shopping Cart is Empty.</strong></p>
		</div>
	</li>
	<li class="cart-menu-btn">
	<a href="index.php">Continue Shopping</a>
	</li>
	</ul>
	</li>
    </ul>
    <?php }?>
</div>
</form>