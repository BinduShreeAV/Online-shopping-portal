<?php
session_start();
error_reporting(0);
include('dbconnection.php');

$pid=intval($_GET['pid']);

//add to cart action
if(isset($_GET['action']) && $_GET['action']=="add"){
	$id=intval($_GET['id']);
	if(isset($_SESSION['cart'][$id])){
		$_SESSION['cart'][$id]['quantity']++;
	}else{
		$sql_p="SELECT * FROM products WHERE id={$id}";
		$query_p=mysqli_query($conn,$sql_p);
		if(mysqli_num_rows($query_p)!=0){
			$row_p=mysqli_fetch_array($query_p);
			$_SESSION['cart'][$row_p['id']]=array("quantity" => 1, "price" => $row_p['productprice']);
		
		}else{
			$message="Product ID is invalid";
		}
	}
		echo "<script>alert('Product has been added to the cart')</script>";
		echo "<script type='text/javascript'> document.location ='cart.php'; </script>";
}


//add to wishlist action
 if(isset($_GET['pid']) && $_GET['action']=="wishlist" ){
	if(strlen($_SESSION['login'])==0)
    header('location:login.php');

else
{

	$product_check_query = "SELECT * FROM wishlist WHERE userid='".$_SESSION['id']."' AND productid='$pid'";
	$query = mysqli_query($conn , $product_check_query);

	if (mysqli_num_rows($query)) 
   {
	  
	  array_push($errors,"Product already exists in your wishlist.");
	  echo "<script type='text/javascript'> alert('Product already exists in your wishlist.'); </script>";
   }
 
     else
	 {
mysqli_query($conn,"INSERT INTO wishlist(userid,productid) values('".$_SESSION['id']."','$pid')");

echo "<script type='text/javascript'> alert('Product as been successfully added into your wishlist.'); </script>";
     
echo "<script type='text/javascript'> document.location = 'wishlist.php'; </script>";

}
}
}

?>


<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Home || HH Stores</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon -->
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <!-- Place favicon.ico in the root directory -->
	<!-- all css here -->
	<!-- style css -->
	<link rel="stylesheet" href="style.css">
	<!-- modernizr js -->
	<script src="js/vendor/modernizr-2.8.3.min.js"></script>
	
	<!-- Cutomer review slider style-->
<style>

* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}

/* Slideshow container */
.slideshow-container {
position: relative;
background: #f1f1f1f1;
}

/* Slides */
.mySlides {
display: none;
padding: 80px;
text-align: center;
}

/* Next & previous buttons */
.prev, .next {
cursor: pointer;
position: absolute;
top: 50%;
width: auto;
margin-top: -30px;
padding: 16px;
color: #888;
font-weight: bold;
font-size: 20px;
border-radius: 0 3px 3px 0;
user-select: none;
}

/* Position the "next button" to the right */
.next {
position: absolute;
right: 0;
border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
background-color: rgba(0,0,0,0.8);
color: white;
}

/* The dot/bullet/indicator container */
.dot-container {
text-align: center;
padding: 20px;
background: #ddd;
}

/* The dots/bullets/indicators */
.dot {
cursor: pointer;
height: 15px;
width: 15px;
margin: 0 2px;
background-color: #bbb;
border-radius: 50%;
display: inline-block;
transition: background-color 0.6s ease;
}

/* Add a background color to the active dot/circle */
.active, .dot:hover {
background-color: #717171;
}

/* Add an italic font style to all quotes */
q {font-style: italic;}

/* Add a blue color to the author */
.author {color: cornflowerblue;}
</style>
</head>

<body>
    <!-- header section start -->
	<header>
	<div class="header-top">
	<div class="container">
	<div class="row">
	<div class="col-xs-12">
	<div class="left floatleft">		
	<ul>
	<?php 
	if(isset($_SESSION['login']))
	{   ?>
	<li>
	<i class="icon fa fa-user"></i>
	<a href="#" style="color:white;"><b>Welcome <?php echo htmlentities($_SESSION['username']);?></b></a>
	</li>
	<?php } ?>								
	<li>
	<i class="fa fa-user"></i> 
	<a href="my-account.php"><b>Account</b></a>
	</li>
	<li>
	<i class="icon fa fa-heart"></i>
	<a href="wishlist.php"><b>Wishlist</b></a>
	</li>
	<?php
	if(isset($_SESSION['login'] ) == 0)
	{?>
    <li>
	<i class="icon fa fa-sign-in"></i>
	<a href="login.php"><b>Login</b></a>
    </li>
	<?php }
    else{ ?>
	<li>
	<i class="icon fa fa-sign-out"></i>
	<a href="logout.php"><b>Logout</b></a>
    </li>
	<?php } ?>		 

	</ul>
	</div>
	</div>
	</div>
	</div>
	</div>
			
	<div id="sticky-menu" class="header-bottom">
	<div class="container">
    <div class="row">
	<div class="col-xs-12 header-bottom-bg">
	<div class="logo floatleft">
	<a href="index.php">
	<img src="img/log.png" alt="Rideo" />
	</a>
	</div>
	<div class="mainmenu text-center floatleft">
	<nav>
	<ul>
	<li>
	    <a href="index.php">Home</a>
    </li>
	<li>
	    <a href="shop.php">products</a>
	</li>
	<li>
		<a href="#">Pages</a>
	<ul>
	<li>
		<a href="my-account.php">My account</a>
	</li>
    <li>
		<a href="wishlist.php">Wishlist</a>
	</li>
	<li>											
		<a href="shop.php">Shop</a>
	</li>
	</ul>
    </li>
	<li>
		<a href="contact.php">contact</a>
	</li>
	</ul>
	</nav>
	</div>
							<!-- mobile menu start -->
							<!-- mobile menu end -->
							<?php include('cart-content.php');?>
						</div>
					</div>
				</div>
			</div>
		</header>
        <!-- header section end -->
		
		<!-- slider section start -->
		<div class="slider-area slider-one clearfix">
			<div class="slider" id="mainslider">
				<div data-src="img/slider/1.jpg">
					<div class="d-table">
						<div class="d-tablecell">
							<div class="container">
								<div class="row">
									<div class="col-xs-12">
										<div class="slide-text">
											<h1 class="animated fadeInDown">best shopping experience</h1>
											<div class="shape animated flipInX">
												<img src="img/slider/shape1.png" alt="" />
											</div>
											<h4 class="animated fadeIn">shop our latest arrivals soon!!</h4>
											<a class="shop-btn animated fadeInUp" href="shop.php">Shop Now</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div data-src="img/slider/1.jpg">
					<div class="d-table">
						<div class="d-tablecell">
							<div class="container">
								<div class="row">
									<div class="col-xs-12">
										<div class="slide-text">
											<h1 class="animated fadeInDown">best Shopping experience</h1>
											<div class="shape animated flipInX">
												<img src="img/slider/shape1.png" alt="" />
											</div>
											<h4 class="animated fadeIn">shop our latest arrivals soon!!</h4>
											<a class="shop-btn animated fadeInUp" href="shop.php">Shop Now</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- slider section end -->
        <!-- featured product section start -->
		<section class="featured-area featured-one section-padding">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-8 col-md-6 col-text-center">
						<div class="section-title text-center">
							<h3><span>Featured</span> products</h3>
							<div class="shape">
								<img src="img/icon/t-shape.png" alt="Title Shape" />
							</div>
						</div>
					</div>
				</div>
				<div class="row text-center">
				<form action="" method="POST" enctype="multipart/form-data">
					<div class="featured-slider single-products">
						<div class="single-slide">
							<div class="padding30">
								
								<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=1 AND category=2");
								while($row=mysqli_fetch_array($result))
								{?>
								<div class="product-item">
									<div class="pro-img">
									<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:230px; height:230px;">';?></a>
									</div>
									<div class="actions-btn">
										<ul class="clearfix">
											<li>
											<?php if($row['productstatus']=='In Stock'){?>
											<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
											</li>
											<li>
											<a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist"><i class="fa fa-heart"></i></a>
												
											</li>
										
										</ul>
									</div>
									<div class="product-title">
										<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>" ><h5>
									<?php echo $row['productname']?></h5></a>
										<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span>
										</p>
										<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?>
										
									</div>
								</div>
								<?}?>
							</div>
						</div>

						<div class="single-slide">
							<div class="padding30">
							<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=30 AND category=5");
								while($row=mysqli_fetch_array($result))
								{?>
								<div class="product-item">
									<div class="pro-img">
									<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:230px; height:230px;">';?></a>
									
																	</div>
									<div class="actions-btn">
										<ul class="clearfix">
											<li>
											<?php if($row['productstatus']=='In Stock'){?>
												<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
											</li>
											<li>
											<a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist"><i class="fa fa-heart"></i></a>
												
											</li>
										
										</ul>
									</div>
									<div class="product-title">
									<a href="product-details.php?pid=<?php echo $row['id']?>"><h5>
									<?php echo $row['productname']?></h5></a>
										<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span></p>
										<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?>
										</div>
								</div>
								<?}?>
							</div>
						</div>
						<div class="single-slide">
							<div class="padding30">
							<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=12 AND category=1");
								while($row=mysqli_fetch_array($result))
								{?>
								<div class="product-item">
									<div class="pro-img">
									<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:230px; height:230px;">';?></a>
									
										
											</div>
									<div class="actions-btn">
										<ul class="clearfix">
											<li>
											<?php if($row['productstatus']=='In Stock'){?>
												<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
											
											</li>
											<li>
											<a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist"><i class="fa fa-heart"></i></a>
												
											</li>
										
										</ul>
									</div>
									<div class="product-title">
									<a href="product-details.php?pid=<?php echo $row['id']?>"><h5>
									<?php echo $row['productname']?></h5></a>
										<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span></p>
										<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?>
										
									</div>
								</div>
								<?}?>
							</div>
						</div>
						<div class="single-slide">
							<div class="padding30">
							<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=62 AND category=11");
								while($row=mysqli_fetch_array($result))
								{?>
								<div class="product-item">
									<div class="pro-img">
									<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:230px; height:230px;">';?></a>
									
									
										</div>
									<div class="actions-btn">
										<ul class="clearfix">
											<li>
											<?php if($row['productstatus']=='In Stock'){?>
												<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
											</li>
											<li>
											<a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist"><i class="fa fa-heart"></i></a>
												
										
										</ul>
									</div>
									<div class="product-title">
									<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"><h5>
									<?php echo $row['productname']?></h5></a>
										<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span></p>
										<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?>
										
										</div>
								</div>
								<?}?>
							</div>
						</div>
						<div class="single-slide">
							<div class="padding30">
							<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=57 AND category=3");
								while($row=mysqli_fetch_array($result))
								{?>

								<div class="product-item">
									<div class="pro-img">
									<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:230px; height:230px;">';?></a>
									
									
											</div>
									<div class="actions-btn">
										<ul class="clearfix">
											<li>
											<?php if($row['productstatus']=='In Stock'){?>
												<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
											
											</li>
											<li>
											<a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist"><i class="fa fa-heart"></i></a>
											</li>
									
										</ul>
									</div>
									<div class="product-title">
									<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"><h5>
									<?php echo $row['productname']?></h5></a>
										<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span></p>
										<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?>
										</div>
								</div>
								<?}?>
							</div>
						</div>
					</div>
					
				</div>
				</form>
			</div>
		</section>
        <!-- featured prodcut section end -->
        <!-- sell-up section start -->
		<form action="" method="POST" enctype="multipart/form-data">
		<section class="sell-up-area sell-up-one">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-4 ">
						<div class="shadow-l-r">
							<div class="sell-up-left">
								<h4>For best handmade products<h4>
								<h2>SHOP NOW <strong>!!</strong></h2>
								<hr class="line"/>
								<ul class="clearfix">
									<li>
										<span></span> With full quality materials
									</li>
									<li>
										<span></span> Long lasting and easy to use
									</li>
									<li>
										<span></span> Hand crafted with love
									</li>
									
								</ul>
								<a class="shop-btn" href="shop.php">Shop Now</a>
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-offset-1 col-md-7">
						<div class="sell-up-right">
						<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=55 AND category=11");
								while($row=mysqli_fetch_array($result))
								{?>
							<div class="single-sellup">
							<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:400px; height:340px;">';?></a>
									
							</div>
								<?php }?>
								<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=9 AND category=2");
								while($row=mysqli_fetch_array($result))
								{?>
							<div class="single-sellup">
							<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:400px; height:340px;">';?></a>
							</div>
							<?php }?>
							<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=88 AND category=2");
								while($row=mysqli_fetch_array($result))
								{?>
							<div class="single-sellup">
							<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:400px; height:340px;">';?></a>
							
							</div>
							<?php }?>
							<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=33 AND category=5");
								while($row=mysqli_fetch_array($result))
								{?>
							<div class="single-sellup">
							<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:400px; height:340px;">';?></a>
							
							</div>
							<?php }?>
						</div>
					</div>
				</div>
			</div>
		</section>
		</form>
	   <!-- sell-up section end -->

	   <!-- Hair Accessories section start -->
	   <form action="" method="POST" enctype="multipart/form-data">
	   <section class="riding-area riding-one section-padding">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-8 col-md-6 col-text-center">
						<div class="section-title text-center">
							<h3><span>Hair</span> accessories</h3>
							<div class="shape">
								<img src="img/icon/t-shape.png" alt="Title Shape" />
							</div>
							<p>"Fashion is the most powerful art there is. It's movement, design and architecture all in one. It shows the world who we are and who we'd like to be."</p>
						</div>
					</div>
				</div>
				<div class="row text-center">
					<div class="four-item riding-slider single-products">
						<div class="riding-item col-xs-12">
						<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=83 AND category=2");
								while($row=mysqli_fetch_array($result))
								{?>
							<div class="product-item">
								<div class="pro-img">
								<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:230px; height:230px;">';?></a>				
								</div>
								<div class="riding-title clearfix">
									<div class="product-title text-left floatleft">
									<?php if($row['productstatus']=='In Stock'){?>
									<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>" ><h5>
									<?php echo $row['productname']?></h5></a>
									<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span>
										</p></div>
									<div class="actions-btn floatright">
										<ul class="clearfix">
											<li>
											<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
												</li>
										</ul>
									</div>
									<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?>
								</div>
							</div>
							<?}?>
						</div>
						<div class="riding-item col-xs-12">
						<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=5 AND category=2");
								while($row=mysqli_fetch_array($result))
								{?>
							<div class="product-item">
								<div class="pro-img">
								<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:230px; height:230px;">';?></a>				
								</div>
								<div class="riding-title clearfix">
									<div class="product-title text-left floatleft">
									<?php if($row['productstatus']=='In Stock'){?>
									<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>" ><h5>
									<?php echo $row['productname']?></h5></a>
									<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span>
										</p></div>
									<div class="actions-btn floatright">
										<ul class="clearfix">
											<li>
											<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
												</li>
										</ul>
									</div>
									<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?>
								</div>
							</div>
							<?}?>
						</div>
						<div class="riding-item col-xs-12">
						<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=3 AND category=2");
								while($row=mysqli_fetch_array($result))
								{?>
							<div class="product-item">
								<div class="pro-img">
								<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:230px; height:230px;">';?></a>				
								</div>
								<div class="riding-title clearfix">
									<div class="product-title text-left floatleft">
									<?php if($row['productstatus']=='In Stock'){?>
									<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>" ><h5>
									<?php echo $row['productname']?></h5></a>
									<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span>
										</p></div>
									<div class="actions-btn floatright">
										<ul class="clearfix">
											<li>
											<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
												</li>
										</ul>
									</div>
									<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?>
								</div>
							</div>
							<?}?>
						</div>
						<div class="riding-item col-xs-12">
						<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=91 AND category=2");
								while($row=mysqli_fetch_array($result))
								{?>
							<div class="product-item">
								<div class="pro-img">
								<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:230px; height:230px;">';?></a>				
								</div>
								<div class="riding-title clearfix">
									<div class="product-title text-left floatleft">
									<?php if($row['productstatus']=='In Stock'){?>
									<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>" ><h5>
									<?php echo $row['productname']?></h5></a>
									<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span>
										</p></div>
									<div class="actions-btn floatright">
										<ul class="clearfix">
											<li>
											<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
												</li>
										</ul>
									</div>
									<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?>
								</div>
							</div>
							<?}?>
						</div>
						<div class="riding-item col-xs-12">
						<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=79 AND category=2");
								while($row=mysqli_fetch_array($result))
								{?>
							<div class="product-item">
								<div class="pro-img">
								<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:230px; height:230px;">';?></a>				
								</div>
								<div class="riding-title clearfix">
									<div class="product-title text-left floatleft">
									<?php if($row['productstatus']=='In Stock'){?>
									<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>" ><h5>
									<?php echo $row['productname']?></h5></a>
									<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span>
										</p></div>
									<div class="actions-btn floatright">
										<ul class="clearfix">
											<li>
											<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
												</li>
										</ul>
									</div>
									<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?>
								</div>
							</div>
							<?}?>
						</div>
					</div>
				</div>
			</div>
		</section>
		</form>
		<!-- Hair Accessories section end -->
		
		 <!-- Shop Now section start -->
		 <form action="" method="POST" enctype="multipart/form-data">
		 <section class="arrival-area arrival-one section-padding-top">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-8 col-md-6 col-text-center">
						<div class="section-title text-center">
							<h3><span>Shop</span> Now</h3>
							<div class="shape">
								<img src="img/icon/t-shape.png" alt="Title Shape" />
							</div>
							
						</div>
					</div>
				</div>
			</div>
			<div class="container-fluid arrival-content">
				<div class="row text-center">
					<div class="col-xs-12 col-md-6 col-lg-4 arrival-left">
						<div class="single-arrival left">
						<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=29 AND category=1");
								while($row=mysqli_fetch_array($result))
								{?>
							<div class="product-item">
								<div class="pro-img">
								<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:450px; height:450px;">';?></a>	
								<div class="tag-new">
									<img src="img/products/tag.png" alt="New Tag" />
								</div>			
								</div>
								
								<div class="actions-btn">
									<ul class="clearfix">
									<li>
											<?php if($row['productstatus']=='In Stock'){?>
												<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
											</li>
											<li>
											<a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist"><i class="fa fa-heart"></i></a>
											</li>
									</ul>
								</div>
								<div class="arrival-title clearfix">
									<div class="product-title">
									<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"><h5>
									<?php echo $row['productname']?></h5></a>
										<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span></p>
										<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?></div>
								</div>
							</div>
							<?}?>
						</div>
					</div>
					<div class="col-xs-12 hidden-md col-lg-4 arrival-middle">
						<div class="single-arrival middel">
							<div class="row">
								<div class="col-sm-6">
								<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=10 AND category=2");
								while($row=mysqli_fetch_array($result))
								{?>
									<div class="product-item">

										<div class="pro-img">
										<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:230px; height:230px;">';?></a>
									</div>
										<div class="actions-btn">
											<ul class="clearfix">
											<li>
											<?php if($row['productstatus']=='In Stock'){?>
												<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
											</li>
											<li>
											<a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist"><i class="fa fa-heart"></i></a>
											</li>
											</ul>
										</div>
										<div class="arrival-title clearfix">
											<div class="product-title">
											  <a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"><h5>
									          <?php echo $row['productname']?></h5></a>
										     <p>Price   <span>Rs.<?php echo
										     $row['productprice']
										     ?> </span></p>
										     <?php } else {?>
										     <div class="action" style="color:red">Out of Stock</div>
										     <?php } ?>
									        </div>
										</div>
									</div>
									<?}?>
									<div class="product-item margin-top">
									<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=53 AND category=11");
								while($row=mysqli_fetch_array($result))
								{?>
										<div class="pro-img">
										<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:230px; height:230px;">';?></a>
									</div>
										<div class="actions-btn">
											<ul class="clearfix">
											<li>
											<?php if($row['productstatus']=='In Stock'){?>
												<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
											</li>
											<li>
											<a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist"><i class="fa fa-heart"></i></a>
											
												</li>
											</ul>
										</div>
										<div class="arrival-title clearfix">
											<div class="product-title">
											<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"><h5>
									<?php echo $row['productname']?></h5></a>
										<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span></p>
										<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?>
										</div>
										</div>
									</div>
									<?}?>
								</div>
								<div class="col-sm-6">
									<div class="product-item">
									<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=63 AND category=11");
								while($row=mysqli_fetch_array($result))
								{?>
										<div class="pro-img">
										<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:230px; height:230px;">';?></a>
									</div>
										<div class="actions-btn">
											<ul class="clearfix">
											<li>
											<?php if($row['productstatus']=='In Stock'){?>
												<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
											</li>
											<li>
											<a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist"><i class="fa fa-heart"></i></a>
											
												</li>
											</ul>
										</div>
										<div class="arrival-title clearfix">
											<div class="product-title">
											<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"><h5>
									<?php echo $row['productname']?></h5></a>
										<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span></p>
										<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?></div>
										</div>
									</div>
									<?}?>
									<div class="product-item margin-top">
									<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=46 AND category=3");
								while($row=mysqli_fetch_array($result))
								{?>
										<div class="pro-img">
										<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:230px; height:230px;">';?></a>
								<div class="tag-new">
									<img src="img/products/tag.png" alt="New Tag" />
								</div>
									</div>
										
										<div class="actions-btn">
											<ul class="clearfix">
											<li>
											<?php if($row['productstatus']=='In Stock'){?>
												<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
											</li>
											<li>
											<a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist"><i class="fa fa-heart"></i></a>
											
												</li>
											</ul>
										</div>
										<div class="arrival-title clearfix">
											<div class="product-title">
											<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"><h5>
									<?php echo $row['productname']?></h5></a>
										<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span></p>
										<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?>
                                          </div>
										</div>
									</div>
									<?}?>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xs-12  col-md-6 col-lg-4 arrival-left">
						<div class="single-arrival right">
						<?php
								$result = mysqli_query($conn, "SELECT * FROM products WHERE id=35 AND category=5");
								while($row=mysqli_fetch_array($result))
								{?>
							<div class="product-item">
								<div class="pro-img">
                                <a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"> 
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:450px; height:450px;">';?></a>
									
									</div>
								<div class="tag-new">
									<img src="img/products/tag.png" alt="New Tag" />
								</div>
								<div class="actions-btn">
									<ul class="clearfix">
									<li>
											<?php if($row['productstatus']=='In Stock'){?>
												<a href="index.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i></a>
											</li>
											<li>
											<a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist"><i class="fa fa-heart"></i></a>
											
										</li>
									</ul>
								</div>
								<div class="arrival-title clearfix">
									<div class="product-title">
									<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"><h5>
									<?php echo $row['productname']?></h5></a>
										<p>Price   <span>Rs.<?php echo
										$row['productprice']
										?> </span></p>
										<?php } else {?>
										<div class="action" style="color:red">Out of Stock</div>
										<?php } ?>
										</div>
								</div>
							</div>
							<?}?>
						</div>
					</div>
				</div>
			</div>
		</section>
		</form>
		<!-- Shop Now section end -->
		<!-- Code for customer reviews slider-->
<br>
<br>
<br>
<br>
<div class="col-sm-6" style="margin-left:53px;">
<h3><b>Customer Reviews</b></h3>
</div>
<br>
<br>


<div class="slideshow-container">
<?php
 $query=mysqli_query($conn,"SELECT * from feedback where feedbackstatus='Active'");
        while($row=mysqli_fetch_array($query))
             {
            ?>
<div class="mySlides">
  <q><?php echo $row['message1'];?></q>
  <p class="author">- <?php echo $row['name1'];?></p>
</div>
<?php } ?>
<a class="prev" onclick="plusSlides(-1)">❮</a>
<a class="next" onclick="plusSlides(1)">❯</a>
</div>


<br>
<br>
<br>
<br>
<br>
<br>

	  
		<footer>
			
			<div class="footer-logo-text">
				<div class="container text-center">
				
				<a href="index.php">
									<img src="img/log2.png" alt="Rideo" />
								</a>
								<p>    Happiness is handmade.</p>
						</div>
			</div>
			<!-- footer top start -->
			<!-- footer top start -->
			<div class="footer-top section-padding">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-4 col-md-4">
							<div class="s-footer-text">
								<div class="footer-title">
									<h4>Contact</h4>
								</div>
								<div class="contact-link">
									<ul>
										<li>
											<span>Email:</span><p>happilyhandmadeonlineportal@gmail.com</p>
										</li>
										<li>
											<span>Phone:</span> <p>

+91-80-26601836<br>

+91-80-26607833
</p>
										</li>
										<li>
											<span>Address:</span><p>

Bugle Rock Rd, Gandhi Bazaar,

Basavanagudi, Bengaluru,

Karnataka 560004
</p>
										</li>
									</ul>
								</div>
								
							</div>
						</div>
						<div class="col-xs-12 col-sm-4 col-md-3">
							<div class="s-footer-text">
								<div class="footer-title">
									<h4>INFORMATION</h4>
								</div>
								<div class="footer-menu">
									<ul>
										<li>
											<a href="contact.php">About Us</a>
										</li>
										<li>
											<a href="index.php">Our Store</a>
										</li>
										<li>
											<a href="contact.php">Feedback</a>
										</li>
										
									</ul>
								</div>
							</div>
						</div>
						
						<div class="col-xs-12 col-sm-2 col-md-2">
							<div class="s-footer-text">
								<div class="footer-title">
									<h4>My Account</h4>
								</div>
								<div class="footer-menu">
									<ul>
										<li>
											<a href="my-account.php">My Orders</a>
										</li>
										<li>
											<a href="wishlist.php">Wishlist</a>
										</li>
										</ul>
								</div>
							</div>
						</div>
						
					</div>
				</div>
			</div>
			<!-- footer top end -->
			<!-- footer top end -->
			<!-- footer bottom start -->
			<div class="footer-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="left floatleft">
								<p>Copyright &copy; 2021 By <a href="http://localhost/hh/index.php">HH Stores</a></p>
							</div>
							<div class="right mayment-card floatright">
								<ul>
									
									<li>
										<a href="#"><img src="img/footer/v6.png" alt="Payment Card" /></a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- footer bottom end -->
		</footer>
		<!-- footer section end -->
		
		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.3.min.js"></script>
		<!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
		<!-- camera slider JS -->
        <script src="js/camera.min.js"></script>
		
		<!-- jquery.easing js -->
        <script src="js/jquery.easing.1.3.js"></script>
		<!-- slick slider js -->
        <script src="js/slick.min.js"></script>
		<!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
		<!-- magnific-popup js -->
        <script src="js/magnific-popup.min.js"></script>
		<!-- countdown js -->
        <!--<script src="js/countdown.js"></script>-->
		<!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
		<!-- plugins js -->
        <script src="js/plugins.js"></script>
		<!-- Google Map JS -->
		<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA_Agsvf36du-7l_mp8iu1a-rXoKcWfs2I"> </script>
		<!-- Custom map-script js -->
        <script src="js/map-script.js"></script>
		<!-- main js -->
		<script src="js/main.js"></script>
		
		<!-- for customer review slider-->
		<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>
    </body>
</html>
