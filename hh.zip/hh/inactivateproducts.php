<?php
include('dbconnection.php');

$v=$_POST['var'];
$inactive = "UPDATE products SET productavailability='Inactive' WHERE id = '$v'";
if(mysqli_query($conn,$inactive))
{
    echo"<script>alert('Successfully Updated');</script>";
    echo "<script>window.location.href='manageproducts.php'</script>";
}
else{
    echo "<script>alert('something went wrong');</script>".mysqli_error($conn);
}
mysqli_close($conn);


?>
