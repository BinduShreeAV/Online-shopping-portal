<?php
session_start();
error_reporting(0);
include('dbconnection.php');

//add to cart action
if(isset($_GET['action']) && $_GET['action']=="add"){
	$id=intval($_GET['id']);	
	
	if(isset($_SESSION['cart'][$id])){
		$_SESSION['cart'][$id]['quantity']++;
	}else{
		$mycustomprice = $_GET['customprice'];
   
		$sql_p="SELECT * FROM products WHERE id={$id}";

		$query_p=mysqli_query($conn,$sql_p);
		if(mysqli_num_rows($query_p)!=0){
			$row_p=mysqli_fetch_array($query_p);

			$_SESSION['cart'][$row_p['id']] = array("quantity" => 1, "price" => $row_p['productprice']);
		
			
		}else{
			$message="Product ID is invalid";
		}
	}
		echo "<script>alert('Product has been added to the cart')</script>";
		echo "<script type='text/javascript'> document.location ='cart.php'; </script>";
}


//add to wishlist action
$pid=intval($_GET['pid']);

 if(isset($_GET['pid']) && $_GET['action']=="wishlist" ){
	if(strlen($_SESSION['login'])==0)
    header('location:login.php');

else
{

	$product_check_query = "SELECT * FROM wishlist WHERE userid='".$_SESSION['id']."' AND productid='$pid'";
	$query = mysqli_query($conn , $product_check_query);

	if (mysqli_num_rows($query)) 
   {
	  
	  array_push($errors,"Product already exists in your wishlist.");
	  echo "<script type='text/javascript'> alert('Product already exists in your wishlist.'); </script>";
   }
 
     else
	 {
mysqli_query($conn,"INSERT INTO wishlist(userid,productid) values('".$_SESSION['id']."','$pid')");

echo "<script type='text/javascript'> alert('Product as been successfully added into your wishlist.'); </script>";
     
echo "<script type='text/javascript'> document.location = 'wishlist.php'; </script>";

}
}
}
?>





<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Product Details || HH Stores</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		
		<!-- favicon -->
         <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
		<!-- all css here -->
		<!-- style css -->
		<link rel="stylesheet" href="style.css">
		<!-- modernizr js -->
		<script src="js/vendor/modernizr-2.8.3.min.js"></script>
		<!--<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">-->
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>


		
    </head>
    <body>
        <!-- header section start -->
		<header>
			<div class="header-top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="left floatleft">
								<ul>
								<?php 
								if(isset($_SESSION['login']))
                                {   ?>
				                <li>
								<i class="icon fa fa-user"></i>
								<a href="#" style="color:white;"><b>Welcome <?php echo htmlentities($_SESSION['username']);?></b></a>
								</li>
								<?php } ?>	
								
								<li>
										<i class="fa fa-user"></i> 
										<a href="my-account.php"><b>Account</b></a>
									</li>
									<li>
									<i class="icon fa fa-heart"></i>
									<a href="wishlist.php"><b>Wishlist</b></a>
									 </li>
									 <?php
									if(isset($_SESSION['login'] ) == 0)
									{?>
                                    <li>
									<i class="icon fa fa-sign-in"></i>
									<a href="login.php"><b>Login</b></a></li>
									<?php }
                                    else{ ?>
				                    <li>
									<i class="icon fa fa-sign-out"></i>
									<a href="logout.php"><b>Logout</b></a></li>
				                    <?php } ?>		 	
								</ul>
							</div>
							
						</div>
					</div>
				</div>
			</div>
			<div id="sticky-menu" class="header-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 header-bottom-bg">
							<div class="logo floatleft">
								<a href="index.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
							</div>
							<div class="mainmenu text-center floatleft">
								<nav>
									<ul>
										<li><a href="index.php">Home</a></li>
										<li>
											<a href="shop.php">products</a>
										</li>
										
										<li><a href="#">Pages</a>
											<ul>
												
												<li>
													<a href="my-account.php">My account</a>
												</li>
											
												<li>
													<a href="wishlist.php">Wishlist</a>
												</li>
											 <li>											
													<a href="shop.php">Shop</a>
												</li>
												

											</ul>
										</li>
										<li>
											<a href="contact.php">contact</a>
										</li>
									</ul>
								</nav>
							</div>
							<!-- mobile menu start -->
							
							<!-- mobile menu end -->
							<?php include('cart-content.php');?>
						
						</div>
					</div>
				</div>
			</div>
		</header>
        <!-- header section end -->
		<!-- page banner area start -->
		<div class="page-banner">
			<img src="img/slider/333.jpg" alt="Page Banner" />
		</div>
		<!-- page banner area end -->
		<!-- product details area start -->
		<form action="custom-product-details.php" method="GET" enctype="multipart/form-data">
		<?php 
					$result=mysqli_query($conn,"SELECT * FROM products WHERE id='$pid'");
					while($row=mysqli_fetch_array($result))
					{
						?>
		<section class="product-details section-padding-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
					<a href="javascript:history.back()" style="color:black;font-size:35px;"><span class="fa fa-arrow-left"></span>
						</a>
						<div class="left">
						
							
							<div class="large-slider zoom-gallery">
								<div>
								<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:550px; height:500px;">';?>
									</div>
							</div>
							
							
						</div>
					</div>

					

					<div class="col-sm-6">
						<div class="right">
						
							<div class="singl-pro-title">

								<h3><?php echo $row['productname']?></h3>
								 <h2 name="customprice" id="customprice">
								 Rs.<?php echo $row['productprice']?>
								 </h2>

								
								<hr />
								<p><?php echo $row['productdescription']?></p><br>
								<p><b>(Go Back to choose other customization option)</b></p>
								<hr />
								
								
								<div class="actions-btn">
									<ul class="clearfix text-center">
										
										
										<?php if($row['productstatus']=='In Stock'){?>
										<li>
											
											<a href="custom-product-details.php?page=product&action=add&id=<?php echo $row['id']; ?>"><i class="fa fa-shopping-cart"></i> add to cart</a>
											

											<?php } else {?>
										<div class="action" style="color:red;font-size:25px;margin-bottom:20px;">Out of Stock</div>
										<?php } ?>
										</li>
										
										<li>
											<a href="custom-product-details.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist"><i class="fa fa-heart"></i></a>
										</li>
									</ul>
								</div>
								<hr />
								<div class="categ-tag">
									
								</div>
								
							</div>
						</div>
					</div>
					<?php }?>
				</div>
				
			</div>
		</section>
		</form>
		
		<footer>
			<!-- brand logo area start -->
			
			<!-- brand logo area end -->
			<!-- contact area start -->
			
			<!-- contact area end -->
			<div class="footer-logo-text">
				<div class="container text-center">
				<a href="index.php">
									<img src="img/log2.png" alt="Rideo" />
								</a>
					<p>Contact Us:   </p>
				<p>	<i class="fa fa-envelope"> </i> happilyhandmadeonlineportal@gmail.com</p>
					
			</div>
			</div>
			<!-- footer top start -->
			
			<!-- footer top end -->
			<!-- footer bottom start -->
			<div class="footer-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="left floatleft">
								<p>Copyright &copy; 2021 By <a href="http://localhost/hh/index.php">HH Stores</a></p>
							</div>
							<div class="right mayment-card floatright">
								<ul>
									
									<li>
										<a href="#"><img src="img/footer/v6.png" alt="Payment Card" /></a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- footer bottom end -->
		</footer>
		<!-- footer section end -->
		
		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.3.min.js"></script>
		<!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
		<!-- camera slider JS -->
        <script src="js/camera.min.js"></script>
		<!-- jquery.easing js -->
        <script src="js/jquery.easing.1.3.js"></script>
		<!-- slick slider js -->
        <script src="js/slick.min.js"></script>
		<!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
		<!-- magnific-popup js -->
        <script src="js/magnific-popup.min.js"></script>
		<!-- countdown js -->
       <!-- <script src="js/countdown.js"></script>-->
		<!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
		<!-- plugins js -->
        <script src="js/plugins.js"></script>
		<!-- main js -->
        <script src="js/main.js"></script>
		
		<!-- Google Map JS -->
		<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA_Agsvf36du-7l_mp8iu1a-rXoKcWfs2I"> </script>
		<!-- Custom map-script js -->
		<script src="js/map-script.js"></script>
	
		
    </body>
</html>
