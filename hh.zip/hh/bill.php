<?php
$conn=new mysqli("localhost","root","","portal");
session_start();
if($conn->connect_error)
{
die("connection failed".$conn->connect_error);
}
else{
	
	
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>HH Stores</title>
	 <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<style type="text/css">
	.invoice-title h2, .invoice-title h3 {
    display: inline-block;
}




.x{
			 
			 z-index:2;
			 width: 75%;
			 height: 40px;
			 
			 border-collapse: collapse;
			 border-spacing: 0;
			 border-radius: 12px 12px 0 0;
			 overflow: hidden;
			 margin-left:3px;

         }
</style>
</head>
<body>
  


<div class="container">
    <div class="row">
        <div class="col-xs-12">
    		<div class="invoice-title">
    			<h2 class="logo"><img src="img/log2.png" style="width: 100px; height: 100px;">&emsp;HH Stores</h2>
    		
           <h4> &emsp;E-Mail : happilyhandmadeonlineportal@gmail.com</h4>
    		</div>
    		<hr>
    		<div class="row">
    			<div class="col-xs-6">
				<?php
                            $query=mysqli_query($conn,"SELECT * from user where user_id='".$_SESSION['id']."'");
                            while($row=mysqli_fetch_array($query))
                            {
                            ?>
    				<address>
    				<strong>Billed To:</strong><br>
    					Name : <?php echo htmlentities($_SESSION['username']);?> <br>
    					E-Mail : <?php echo $row['email_id'];?><br>
    					Phone Number : <?php echo $row['mobile_no'];?><br>
    					Address : <?php echo $row['shippingaddress'];?>
    				</address>
    			</div>
				<div class="row">
                           <div class="col-xs-6">
                         
                     </div>
					 <address>
              <strong>Order Date:</strong><br>
              <?php  $date = new DateTime();
                echo $date->format('d-m-Y 	') . "\n";
                ?>
            </address>
            </div>
	</div>
			<?php } ?>

			
    		
		        <table class="x" >
									<thead>
										<tr>
											<th>Product</th>
											<th>Quantity</th>
											<th>Total <small>(Incl. Shipping Charges)</small></th>
										</tr>
									</thead>
									<tbody>
									<?php
                               $pdtid=array();
                               $sql = "SELECT * FROM products WHERE id IN(";
			                   foreach($_SESSION['cart'] as $id => $value){
			                   $sql .=$id. ",";
			                   }
			                   $sql=substr($sql,0,-1) . ") ORDER BY id ASC";
			                   $query = mysqli_query($conn,$sql);
			                   $totalprice=0;
							   $totalqunty=0;
							   $shippingcharges=0;
							   $sub=0;
							 
			                   if(!empty($query)){
			                   while($row = mysqli_fetch_array($query)){
							   $quantity=$_SESSION['cart'][$row['id']]['quantity'];

				               $subtotal= $_SESSION['cart'][$row['id']]['quantity']*$row['productprice']+$row['shippingcharges'];
				               $totalprice += $subtotal;
							   $_SESSION['qnty']=$totalqunty+=$quantity;	   
							   $sub+= $_SESSION['cart'][$row['id']]['quantity']*$row['productprice'];
							   $shippingcharges += $row['shippingcharges'];
							   
				               array_push($pdtid,$row['id']);
	                           ?>

										<tr>
											<td class="td-text">
												<div class="order-dsc">
												<p><?php echo $row['productname'];
						
												?>
												</p>
												</div>
											</td>

											<td>
											<?php echo $_SESSION['cart'][$row['id']]['quantity']; ?>
							                </td>
											
											<td>
											<span class="cart-grand-total-price"><?php echo "Rs"." ".($_SESSION['cart'][$row['id']]['quantity']*$row['productprice']+$row['shippingcharges']); ?>.00</span>
											</td>
										</tr>
										   <?php } }
                                           $_SESSION['pid']=$pdtid;
										  ?>
										  
										  <tr style="margin-top:20px;">
											  <td>
											  <strong>Grand Total</strong><br>
    				                        	<?php  echo "Rs"." ".$totalprice?>
											  </td>
										  </tr>
										  
									</tbody>
								
								</table>
								
								<br>
								<div class="text-center">
		                       <button onclick="window.print();" class="btn btn-primary" id="print-btn">Print</button>
		                       <?php unset($_SESSION['cart']);?>
	                          <a href=cart.php><button>back</button> </a>
                                </div>	
								
    
                    </div> 
     </div>
</div>

</body>

      
</html>
							   <? }?>