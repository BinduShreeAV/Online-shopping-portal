<?php

require('config.php');
session_start();
//db connection
$conn = mysqli_connect($host, $username, $password, $dbname);

require('razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$success = true;

$error = "Payment Failed";

if (empty($_POST['razorpay_payment_id']) === false)
{
    $api = new Api($keyId, $keySecret);

    try
    {
        // Please note that the razorpay order ID must
        // come from a trusted source (session here, but
        // could be database or something else)
        $attributes = array(
            'razorpay_order_id' => $_SESSION['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature']
        );

        $api->utility->verifyPaymentSignature($attributes);
    }
    catch(SignatureVerificationError $e)
    {
        $success = false;
        $error = 'Razorpay Error : ' . $e->getMessage();
    }
}

if ($success === true)
{
    $razorpay_order_id = $_SESSION['razorpay_order_id'];
    $razorpay_payment_id = $_POST['razorpay_payment_id'];
   // $email = $_SESSION['email'];
    $totalprice = $_SESSION['totalprice'];
    $sql = "INSERT INTO `payment` (`order_id`, `razorpay_payment_id`, `status`, `totalprice`) VALUES ('$razorpay_order_id', '$razorpay_payment_id', 'success', '$totalprice')";
    if(mysqli_query($conn, $sql)){
       // echo "payment details inserted to db";
    }
    $check=mysqli_query($conn,"UPDATE orders SET paymentmethod='Razorpay' where userid='".$_SESSION['id']."' and paymentmethod is null ");
    if($check){
        echo "<script>alert('Your order has been successfully placed.')</script>";
    
    
    echo "<script type='text/javascript'> document.location ='bill.php'; </script>";
}
  //  echo "<script type='text/javascript'> document.location ='checkout2.php'; </script>";
  //  $html = "<p>Your payment was successful</p>
     //      <p>Payment ID: {$_POST['razorpay_payment_id']}</p>";-->

    
}
else
{
    $html = "<p>Your payment failed</p>
             <p>{$error}</p>";
}

echo $html;
