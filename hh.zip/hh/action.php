<?php

include('dbconnection.php');
session_start();

if(isset($_POST['submit'])){
 
$orderstatus=$_POST['orderstatus'];


$pd=$_POST['oid1'];


    $check=mysqli_query($conn,"UPDATE orders SET orderstatus='".$_POST['orderstatus']."' WHERE orderdate='$pd'  ");
    if($check){
        echo "<script>alert('Order status has been successfully updated.')</script>";
    
    
    echo "<script type='text/javascript'> document.location ='todays-order.php'; </script>";
    
    
}
}	
   

?>