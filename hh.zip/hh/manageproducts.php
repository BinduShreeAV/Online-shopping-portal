<?php
session_start();
include('dbconnection.php');

if(strlen($_SESSION['alogin'])== 0)
    {   
header('location:adminlogin.php');
}
else
{
	$sql="SELECT products.*,category.categoryname as catname from products join category ON products.category=category.id";
    $r = mysqli_query($conn,$sql);
	
	

	
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UFT-8">
  <title>HH Stores</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
    <style>
  	   @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');
		 <?php include('adminstyle.css'); ?>   
		 .manage-form{
			 background-color: white;
			
		 }

         .x{
			 position: absolute;
			 z-index:2;
			 width: 75%;
			 height: 40px;
			 background:#fafafa;
			 text-align: center;
			 border-collapse: collapse;
			 border-spacing: 0;
			 border-radius: 12px 12px 0 0;
			 overflow: hidden;
			 

         }

         th,td{
			 padding: 7px 13px;
		 }

		 th{
			 background: orange;
			 color: #fafafa;
			 font-size: 17px;
		 }

		 tr:nth-child(odd){
			 background-color: #eeeeee;
		 }
		 
		 .d-btn{
			 background-color:#2b88d8;
			 color: white;
			 border: none;
			 letter-spacing: 1.5px;
			 padding: 4px;
			 
		 }
		 .d-btn:hover{
			background-color: rgba(242, 38, 19, 1);
			color: white;
			font-weight:500;
		 }
		.am{
			background-color:#2b88d8;
			 color: white;
			 border: none;
			 letter-spacing: 1.5px;	 
			 padding:  4px;
		}
		.am:hover{
			background-color: rgba(38, 166, 91, 1);
			color: white;
			font-weight:500;
		}	
		.am1{
			background-color:#2b88d8;
			 color: white;
			 border: none;
			 letter-spacing: 1.5px;	 
			 padding:  4px;
			 margin-bottom: 4px;
		}
		.am1:hover{
			background-color: rgba(38, 166, 91, 1);
			color: white;
			font-weight:500;
		}	
  </style>
</head>
<body>
	<div class="sidebar">
		<div class="sidebar-brand">
		<a href="adminhome.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
		</div>
		<br>
		<div class="sidebar-menu">
			<ul>
				<li>
					<a href="adminhome.php"><span class="fas fa-igloo"></span>
						<span>Dashboard</span></a>
				</li>
				<li>
					<a href="addproducts.php" ><span class="fas fa-plus-square"></span>
						<span>Add Products</span></a>
				</li>
				
				<li>
					<a href="manageproducts.php" class="active"><span class="fas fa-cogs"></span>
						<span>Manage Products</span></a>
				</li>
				
				<li>
					<a href="viewcustomers.php"><span class="fas fa-users"></span>
						<span>View Customers</span></a>
				</li>
				<li>
					<a href="viewfeedbacks.php"><span class="fas fa-comments"></span>
						<span>View Feedbacks</span></a>
				</li>
				<li class="item">
					<a href="" class="order-btn"><span class="fas fa-tasks"></span>
						<span>Order Management <i class="fas fa-chevron-down drop-down"></i></span></a>
						<ul class="sub-menu">
                        <li>
                        <a href="todays-order.php"><span class="fas fa-clipboard-list"></span>
						<span>Today's Order</span></a>   
                        </li>
                        <li>
                        <a href="pending-orders.php"><span class="fas fa-clock"></span>
						<span>Pending Orders</span></a>   
						</li>
						<li>
						<a href="outfordelivery-orders.php"><span class="fas fa-clipboard-check"></span>
						<span>Out For Delivery Orders</span></a>   
                        </li>
                        <li>
                        <a href="delivered-orders.php"><span class="fas fa-clipboard-check"></span>
						<span>Delivered Orders</span></a>   
                        </li>
                        </ul>                    
				</li>
				<li>
					<a href="logout1.php"><span class="fas fa-sign-out-alt"></span>
						<span>Sign Out</span></a>
				</li>
			</ul>
		</div>
	</div>
	<div class="main-content">
		<header>
			<h2>
				Manage Products
			</h2>
			<div>
				
                <a class="user-wrapper" href="adminhome.php"><span class="fas fa-user-shield"></span>
						<span><h3>Admin</h3></span></a>

			</div>
		</header>
	
<main>
<form id="manageproducts" class="manage-form" method="post" action="manageproducts.php">
   <table class="x">
   <tr>
   <th>Id</th>
   <th>Product Name</th>
   <th>Category</th>
   <th>Price</th>
   <th>Product Availability</th>
   <th>Product Status</th>
   <th>Update</th>
   <th>Add Customization</th>
   <th>Set Status</th>
   </tr>
 
 <?php
   $cnt=1;
   while($cols=mysqli_fetch_assoc($r)){

?>
<td>  <?php echo $cnt ?> </td>
<td>  <?php echo $cols['productname']?> </td>
<td>  <?php echo $cols['catname']?> </td>
<td>  <?php echo $cols['productprice']?> </td>
<td>  <?php echo $cols['productavailability']?> </td>
<td>  <?php echo $cols['productstatus']?> </td>


<td><a class="am" href="updateproducts.php?id=<?php echo $cols['id'];?>">Edit</a></td>

<td><a class="am" href="addcustomization.php?id=<?php echo $cols['id'];?>">Customize</a></td>




<td>

<form action="activateproducts.php" method="post">
<input type="submit" name="active" class="am1" value="Activate" /><br>
<input type="hidden" name="var" value="<?php echo $cols['id'];?>"/>
</form>


  <form action="inactivateproducts.php" method="post">
      <input type="submit" name="inactive" class="d-btn" onClick="return confirm('Are you sure you want to inactivate the product?')" value="Inactivate" />
      <input type="hidden" name="var" value="<?php echo $cols['id'];?>"/>
      </form>
</td>
</tr>
<?php
	$cnt++;
}
?>


   


   
</table>
</form>
</main>
</div>
</body>
</html>
<?php } ?>