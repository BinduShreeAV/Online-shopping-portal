<?php

include('dbconnection.php');
session_start();


$proid="";
$category="";
$property="";
$productprice="";
$pid=$_POST['pid'];

if(isset($_POST['submit'])){
$proid = isset($_POST['proid'])? $_POST['proid']:' ';
    $category = isset($_POST['category'])? $_POST['category']:' ';
    $property = isset($_POST['property'])? $_POST['property']:' ';
	$productprice = isset($_POST['productprice'])? $_POST['productprice']:' ';
	$productimage = addslashes(file_get_contents($_FILES["productimage"]["tmp_name"]));
     $customizedproductname =isset($_POST['customizedproductname'])? $_POST['customizedproductname']:' ';
    if(empty($proid)){array_push($errors,"Product Name is required.");}
    if(empty($category)){array_push($errors,"Category is required.");}
    if(empty($property)){array_push($errors,"Property is required.");}
	if(empty($productprice)){array_push($errors,"Price is required.");}
	if(empty($productimage)){array_push($errors,"Product Image is required.");}
	if(empty($customizedproductname)){array_push($errors,"Customized name is required.");}

	

	


    if(count($errors) == 0)
    {

        
     $q = "INSERT INTO customization (proid,category,property) 
   VALUES('$proid','$category','$property')";
		mysqli_query($conn,$q);    
		


		$q1 = "SELECT * FROM products where id = '$pid'";
		$res= mysqli_query($conn,$q1);
		$f = mysqli_fetch_assoc($res);

		$cat = $f['category'];
		$productowner = $f['productowner'];
		$productdescription = $f['productdescription'];
		$shippingcharges = $f['shippingcharges'];
		$productquantity = $f['productquantity'];
		$productstatus = $f['productstatus'];
		$productavailability = $f['productavailability'];
		
  $query="INSERT INTO products (category,productname,productowner, productprice,productdescription,productimage,shippingcharges,productquantity,productstatus,productavailability,mainproduct) 
 values ('$cat', '$customizedproductname', '$productowner',  '$productprice','$productdescription','$productimage','$shippingcharges', '$productquantity' ,'$productstatus' ,'$productavailability',0)";
 
 mysqli_query($conn,$query);    

		


 

        echo "<script type='text/javascript'> alert('Product customization properties has been added successfully.'); </script>";
    
    echo "<script type='text/javascript'> document.location = 'manageproducts.php'; </script>";
   

 }   
}
?>