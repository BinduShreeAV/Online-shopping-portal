<?php
session_start();
error_reporting(0);
include('dbconnection.php');

if(isset($_POST['submit'])){
	if(!empty($_SESSION['cart'])){
	foreach($_POST['quantity'] as $key => $val){
		if($val==0){
			unset($_SESSION['cart'][$key]);
		}else{
			$_SESSION['cart'][$key]['quantity']=$val;

		}
	}
		echo "<script>alert('Your Cart has been Updated');</script>";
	}
}



// code for insert product in order table
 if(isset($_POST['ordersubmit'])) 
	{
     if(strlen($_SESSION['login'])==0)  
      header('location:login.php');
    
    else{
	
	$price = $_SESSION['tp'];
	$quantity=$_POST['quantity'];
	$pdd=$_SESSION['pid'];
	$value=array_combine($pdd,$quantity);
     $value1=array_combine($pdd,$proname);
	 foreach($value as $qty => $val34){
      mysqli_query($conn,"INSERT INTO orders (userid,productid,quantity,orderstatus,amount_paid) values('".$_SESSION['id']."','$qty','$val34','Pending','$price')");
	  echo "<script>alert('hdgj');</script>";	
	 header('location:checkout.php');

   }
   }
}
;
	
//code to remove a product from cart
if($_GET['action']=="remove"){

if(!empty($_SESSION['cart'])){
	$id=intval($_GET['id']);
	unset($_SESSION['cart'][$id]);
	
		echo "<script>alert('Product has been removed.');</script>";
}
}






// code for Shipping address updation
if(strlen($_SESSION['login'])==0)
    {   
header('location:login.php');
}
else{
if(isset($_POST['shipupdate']))
{
	$saddress=$_POST['shippingaddress'];
	$sstate=$_POST['shippingstate'];
	$scity=$_POST['shippingcity'];
	$spincode=$_POST['shippingpincode'];
	$query=mysqli_query($conn,"UPDATE user set shippingaddress='$saddress',shippingstate='$sstate',shippingcity='$scity',shippingpincode='$spincode' where user_id='".$_SESSION['id']."'");
	if($query)
	{
echo "<script>alert('Shipping Address has been updated');</script>";
	}
}
}


?>




<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Cart || HH Stores</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- favicon -->
     <!--  <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">-->
        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
		<!-- all css here -->
		<!-- style css -->
		<link rel="stylesheet" href="style.css">
		<!-- modernizr js -->
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
        

        <!-- header section start -->
		<header>
			<div class="header-top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="left floatleft">
								<ul>
									<?php 
								if(isset($_SESSION['login']))
                                {   ?>
				                <li>
								<i class="icon fa fa-user"></i>
								<a href="#" style="color:white;"><b>Welcome <?php echo htmlentities($_SESSION['username']);?></b></a>
								</li>
								<?php } ?>	
								
								<li>
										<i class="fa fa-user"></i> 
										<a href="my-account.php"><b>Account</b></a>
									</li>
									<li>
									<i class="icon fa fa-heart"></i>
									<a href="wishlist.php"><b>Wishlist</b></a>
									 </li>
									 <?php
									if(isset($_SESSION['login'] ) == 0)
									{?>
                                    <li>
									<i class="icon fa fa-sign-in"></i>
									<a href="login.php"><b>Login</b></a></li>
									<?php }
                                    else{ ?>
				                    <li>
									<i class="icon fa fa-sign-out"></i>
									<a href="logout.php"><b>Logout</b></a></li>
				                    <?php } ?>	
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div id="sticky-menu" class="header-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 header-bottom-bg">
							<div class="logo floatleft">
								<a href="index.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
							</div>
							<div class="mainmenu text-center floatleft">
								<nav>
									<ul>
										<li><a href="index.php">Home</a></li>
										<li>
											<a href="shop.php">products</a>
										</li>
										
										
										</li>
										<li><a href="#">Pages</a>
											<ul>
												
												<li>
													<a href="my-account.php">My account</a>
												</li>
												
												<li>
													<a href="wishlist.php">Wishlist</a>
												</li>
												<li>
													<a href="shop.php">Shop</a>
												</li>												
													
											</ul>
										</li>
										<li>
											<a href="contact.php">contact</a>
										</li>
									</ul>
								</nav>
							</div>
							<!-- mobile menu start -->
							
							<!-- mobile menu end -->
							<?php include('cart-content.php');?>
						</div>
					</div>
				</div>
			</div>
		</header>
        <!-- header section end -->
		<!-- page banner area start -->
		<div class="page-banner">
			<img src="img/slider/333.jpg" alt="Page Banner" />
		</div>
		<!-- page banner area end -->
		<!-- cart page content section start -->
		<form name="cart" method="post"  action="cart.php">
		<section class="cart-page section-padding">
			<div class="container">
				<div class="row">
					<div class="col-xs-15">
						<div class="table-responsive table-one margin-minus section-padding-bottom">
						<?php
                          if(!empty($_SESSION['cart'])){
	                    ?>
							<table class="spacing-table text-center">
								<thead>
									<tr>
										<th>Product</th>
										<th>Quantity</th>
										<th>Unit Price</th>
										<th>Shipping Charge</th>
										<th>Grand Total</th>
										<th>Remove</th>
									</tr>
								</thead>

								<tfoot>
									<tr>
									<td colspan="20">
										
										
									
										<div>
										<a href="index.php" class="btn btn-upper btn-primary outer-left-xs" style="margin-right:750px;">Continue Shopping</a>
										<input type="submit"  name="submit"  value="UPDATE CART" class="btn btn-upper btn-primary pull-right outer-right-xs"> 
									</div>
									</td>

									</tr>
								</tfoot>
								
								<tbody>
								<?php
                               $pdtid=array();
                               $sql = "SELECT * FROM products WHERE id IN(";
			                   foreach($_SESSION['cart'] as $id => $value){
			                   $sql .=$id. ",";
			                   }
			                   $sql=substr($sql,0,-1) . ") ORDER BY id ASC";
			                   $query = mysqli_query($conn,$sql);
			                   $totalprice=0;
			                   $totalqunty=0;
			                   if(!empty($query)){
			                   while($row = mysqli_fetch_array($query)){
					
				               $quantity=$_SESSION['cart'][$row['id']]['quantity'];
				               $subtotal= $_SESSION['cart'][$row['id']]['quantity']*$row['productprice']+$row['shippingcharges'];
				               $totalprice += $subtotal;
				               $_SESSION['qnty']=$totalqunty+=$quantity;
							   array_push($pdtid,$row['id']);
							   
	                           ?>
									<tr>
										<td class="td-img text-left">
										<a href="#"> 
										<?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:240px; height:190px;">';?>
									    </a>
											
											<div class="items-dsc">
												<p><a href="#" ><?php echo $row['productname'];
												
												?>
												</p>
											</div>
										</td>
										
										<td class="cart-product-quantity">
												<div class="plus-minus">
													<a class="dec qtybutton">-</a>
													<input type="text" value="<?php echo $_SESSION['cart'][$row['id']]['quantity']; ?>" name="quantity[<?php echo $row['id']; ?>]" class="plus-minus-box">
													<a class="inc qtybutton">+</a>
												</div>
										</td>
										<td><span class="cart-sub-total-price"><?php echo "Rs"." ".$row['productprice']; ?>.00</span></td>
										<td><span class="cart-sub-total-price"><?php echo "Rs"." ".$row['shippingcharges']; ?>.00</span></td>
										<td><span class="cart-grand-total-price"><?php echo "Rs"." ".($_SESSION['cart'][$row['id']]['quantity']*$row['productprice']+$row['shippingcharges']); ?>.00</span></td>
										<td class="remove-item"> 
										<div>
								
									<a href="cart.php?action=remove&id=<?php echo $row['id']; ?>"><i class="fa fa-trash"></i></a>
	
							          </div>
										
										</td>

									</tr>
									<?php } }
                                    $_SESSION['pid']=$pdtid;
				                    ?>
									
							
								
								</tbody>
							
									
							</table>
							

						
					</div>
					
				</div>





				<div class="row">
					
					<div class="col-sm-4">
						
						<div class="estimate-text">
							<h3><strong>Shipping Address</strong></h3>
							<?php
                            $query=mysqli_query($conn,"SELECT * FROM user where user_id='".$_SESSION['id']."'");
                            while($row=mysqli_fetch_array($query))
                            {
                            ?>
							
								<div class="single-select">
									<label>Shipping Address *</label>
									<textarea class="form-control unicase-form-control text-input"  name="shippingaddress" required="required"><?php echo $row['shippingaddress'];?></textarea>
								</div>
								<div class="single-select">
									<label>Shipping State *</label>
									<input type="text" class="form-control unicase-form-control text-input" id="shippingstate" name="shippingstate" value="<?php echo $row['shippingstate'];?>" required="required">
	
								</div>
								<div class="single-select">
									<label>Shipping City *</label>
									<input type="text" class="form-control unicase-form-control text-input" id="shippingcity" name="shippingcity" value="<?php echo $row['shippingcity'];?>" required="required">
	
								</div>
								<div class="single-select">
									<label>Zip/Postal Code *</label>
								    <input type="text" class="form-control unicase-form-control text-input" id="shippingpincode" name="shippingpincode" required="required" value="<?php echo $row['shippingpincode'];?>">
	
							</div>
							<div>
									<div class="submit-text quotes">
										<input type="submit" name="shipupdate" value="UPDATE">
									</div>

								</div>
								<?php } ?>
								</form>
						</div>
					</div>
				<div class="col-sm-4">
						<!--	<div class="estimate-text coupon">
							<h3>Discount Code</h3>
							<p>Enter your coupon code if you have one</p>
							<form action="mail.php" method="post">
								<div class="input-text">
									<input type="text" name="coupon" />
								</div>
								<div class="submit-text">
									<input type="submit" name="submit" value="Apply Coupon">
								</div>
							</form>
						</div>-->
					</div>
					<div class="col-sm-4">
						<div class="estimate-text responsive">
							<div class="subtotal clearfix">
								
								<p>Grandtotal: <span class="floatright">Rs. <?php echo $_SESSION['tp']="$totalprice". ".00"; ?></span></p>
							</div>
							<div class="default-btn text-right">
							<div class="submit-text quotes">
										<input type="submit" name="ordersubmit" value="PROCEED TO CHECKOUT"/>
									</div>
							</div>
						</div>
					</div>
					<?php } else {
                 echo "Your shopping Cart is empty";
	           } ?>
				</div>
			</div>
		</section>
		
		
		<footer>
			
			
			
			<div class="footer-logo-text">
				<div class="container text-center">
					<a href="index.php"><img src="img/log2.png" alt="Logo" /></a>
					<p>Contact Us:   </p>
				<p>	<i class="fa fa-envelope"> </i> happilyhandmadeonlineportal@gmail.com</p>
					
				</div>
			</div>
			<!-- footer top start -->
			
			<!-- footer top end -->
			<!-- footer bottom start -->
			<div class="footer-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="left floatleft">
							<p>Copyright &copy; 2021 By <a href="http://localhost/hh/index.php">HH Stores</a></p>
								
						</div>
							<div class="right mayment-card floatright">
								<ul>
									
									<li>
										<a href="#"><img src="img/footer/v6.png" alt="Payment Card" /></a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- footer bottom end -->
		</footer>
		<!-- footer section end -->
		
		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.3.min.js"></script>
		<!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
		<!-- camera slider JS -->
        <script src="js/camera.min.js"></script>
		<!-- jquery.easing js -->
        <script src="js/jquery.easing.1.3.js"></script>
		<!-- slick slider js -->
        <script src="js/slick.min.js"></script>
		<!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
		<!-- magnific-popup js -->
        <script src="js/magnific-popup.min.js"></script>
		<!-- countdown js -->
      <!--  <script src="js/countdown.js"></script>-->
		<!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
		<!-- plugins js -->
        <script src="js/plugins.js"></script>
		<!-- main js -->
        <script src="js/main.js"></script>
		
		<!-- Google Map JS -->
		<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA_Agsvf36du-7l_mp8iu1a-rXoKcWfs2I"> </script>
		<!-- Custom map-script js -->
        <script src="js/map-script.js"></script>
    </body>
</html>

