<?php
//database connection
include('dbconnection.php');
session_start();

if(strlen($_SESSION['alogin'])== 0)
    {   
header('location:adminlogin.php');
}
else
{
	$sql="SELECT COUNT(user_id) as max1 FROM user";
    $query = mysqli_query($conn,$sql);
    
    $r = "SELECT COUNT(id) as mvotes FROM products WHERE mainproduct=1";
    $q = mysqli_query($conn,$r);

	$r1 = "SELECT  COUNT(DISTINCT orderdate) as torders FROM orders";
	$q1 = mysqli_query($conn,$r1);
	
	
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UFT-8">
  <title>HH Stores</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
    <style>
		 @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');
		 <?php include('adminstyle.css'); ?>  
		 td{
			 color: orange;
			 font-size: 100px;
			 padding-right: 9.5rem;
			 padding-left: 3.2rem;
			 font-weight: 600;
		 }
		 

  </style>


</head>
<body>
	<div class="sidebar">
    <div  class="sidebar-brand">
	<a href="adminhome.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
			
		</div>
		<br>
		<div class="sidebar-menu">
			<ul>
				<li>
					<a href="adminhome.php" class="active"><span class="fas fa-igloo"></span>
						<span>Dashboard</span></a>
				</li>
				<li>
					<a href="addproducts.php"><span class="fas fa-plus-square"></span>
						<span>Add Products</span></a>
				</li>
				
				<li>
					<a href="manageproducts.php"><span class="fas fa-cogs"></span>
						<span>Manage Products</span></a>
				</li>
				<li>
					<a href="viewcustomers.php"><span class="fas fa-users"></span>
						<span>View Customers</span></a>
				</li>
				<li>
					<a href="viewfeedbacks.php" ><span class="fas fa-comments"></span>
						<span>View Feedbacks</span></a>
				</li>
				<li class="item">
                
					<a href=""  class="order-btn"><span class="fas fa-tasks"></span>
						<span>Order Management <i class="fas fa-chevron-down drop-down"></i> </span></a>   
                        <ul class="sub-menu">
                        <li>
                        <a href="todays-order.php"><span class="fas fa-clipboard-list"></span>
						<span>Today's Order</span></a>   
                        </li>
                        <li>
                        <a href="pending-orders.php"><span class="fas fa-clock"></span>
						<span>Pending Orders</span></a>   
						</li>
						<li>
                        <a href="outfordelivery-orders.php"><span class="fas fa-clipboard-check"></span>
						<span>Out For Delivery Orders</span></a>   
                        </li>
                        <li>
                        <a href="delivered-orders.php"><span class="fas fa-clipboard-check"></span>
						<span>Delivered Orders</span></a>   
                        </li>
                        </ul>                    

				</li>
				
				<li>
					<a href="logout1.php"><span class="fas fa-sign-out-alt"></span>
						<span>Sign Out</span></a>
				</li>
			</ul>
		</div>
	</div>
	<div class="main-content">
		<header>
			<h2>
				Dashboard
			</h2>
			<div class="user-wrapper">
                <a class="user-wrapper" href="adminhome.php">
				<span class="fas fa-user-shield"></span>
				<span><h3>Admin</h3></span></a>
			</div>
			
		</header>
		<main>
			<div class="cards">
				<div class="card-single">
					<div>
						<h1>
						<?php  while($cols=mysqli_fetch_assoc($query))
		               {
			           echo $cols['max1'];
		               }
		               ?>
						</h1>
						<span>Customers</span>
					</div>
					<div>
						<span class="fas fa-users"></span>
					</div>
					
				</div> 
				
				<div class="card-single">
					<div>
						<h1><?php  while($cols=mysqli_fetch_array($q1))
		               {
			           echo $cols['torders'];
		               }
		               ?></h1>
						<span>Orders</span>
					</div>
					<div>
						<span class="fas fa-boxes"></span>
					</div>
				</div>
				<div class="card-single">
					<div>
						<h1> 
						<?php  while($cols=mysqli_fetch_assoc($q))
		               {
			           echo $cols['mvotes'];
		               }
		               ?></h1>
						<span>Products</span>
					</div>
					<div>
						<span class="fas fa-box-open"></span>
					</div>
				</div>

			</div>
			
		</main>
	</div>
</body>
</html>
<?php } ?>