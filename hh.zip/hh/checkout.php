<?php
session_start();
//error_reporting(0);
include('dbconnection.php');

if(strlen($_SESSION['login'])==0)
{  
header('location:login.php');
}
else{
	if (isset($_POST['submit'])) {
		$check=mysqli_query($conn,"UPDATE orders SET paymentmethod='".$_POST['gender']."' where userid='".$_SESSION['id']."' and paymentmethod is null ");
		if($check){
			echo "<script>alert('Your order has been successfully placed.')</script>";
			echo "<script type='text/javascript'> document.location ='bill.php'; </script>";
		
		
		
		
		}
	}


?>








<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Checkout || HH Stores</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- favicon -->
      <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
		<!-- all css here -->
		<!-- style css -->
		<link rel="stylesheet" href="style.css">
		<!-- modernizr js -->
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
       

        <!-- header section start -->
		<header>
			<div class="header-top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="left floatleft">
								<ul>
								<?php 
								if(isset($_SESSION['login']))
                                {   ?>
				                <li>
								<i class="icon fa fa-user"></i>
								<a href="#" style="color:white;"><b>Welcome <?php echo htmlentities($_SESSION['username']);?></b></a>
								</li>
								<?php } ?>	
								
								<li>
										<i class="fa fa-user"></i> 
										<a href="my-account.html"><b>Account</b></a>
									</li>
									<li>
									<i class="icon fa fa-heart"></i>
									<a href="wishlist.php"><b>Wishlist</b></a>
									 </li>
									 <?php
									if(isset($_SESSION['login'] ) == 0)
									{?>
                                    <li>
									<i class="icon fa fa-sign-in"></i>
									<a href="login.php"><b>Login</b></a></li>
									<?php }
                                    else{ ?>
				                    <li>
									<i class="icon fa fa-sign-out"></i>
									<a href="logout.php"><b>Logout</b></a></li>
				                    <?php } ?>		
								</ul>
							</div>
							
						</div>
					</div>
				</div>
			</div>
			<div id="sticky-menu" class="header-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 header-bottom-bg">
							<div class="logo floatleft">
								<a href="index.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
							</div>
							<div class="mainmenu text-center floatleft">
								<nav>
									<ul>
										<li><a href="index.php">Home</a></li>
										<li>
											<a href="shop.php">products</a>
										</li>
										
										</li>
										<li><a href="#">Pages</a>
											<ul>
												
												<li>
													<a href="my-account.php">My account</a>
												</li>
												
												<li>
													<a href="wishlist.php">Wishlist</a>
												</li>
												
												<li>
													<a href="shop.php">Shop</a>
												</li>												
													
											</ul>
										</li>
										<li>
											<a href="contact.php">contact</a>
										</li>
									</ul>
								</nav>
							</div>
							<!-- mobile menu start -->
							
							<!-- mobile menu end -->
							<?php include('cart-content.php');?>
						</div>
					</div>
				</div>
			</div>
		</header>
        <!-- header section end -->
		<!-- page banner area start -->
		<div class="page-banner">
			<img src="img/slider/333.jpg" alt="Page Banner" />
		</div>
		<!-- page banner area end -->
		<!-- cart page content section start -->
		<section class="cart-page section-padding">
			<div class="container">	
				<div class="row">
					<div class="col-sm-6">
						<div class="row">
							<div class="single-check responsive">
								<form action="mail.php" method="post">
									<div class="single-input p-bottom50 clearfix">
									
							
										<div class="col-xs-12">
										<div class="check-title">
								<h3>Your Order</h3>
							</div>
							<div class="table-responsive table-two">
								<table class="order-table text-center">
									<thead>
										<tr>
											<th>Product</th>
											<th>Quantity</th>
											<th>Total <div style="margin-top:-28px;"><small>(Incl. Shipping Charges)</small></div></th>
										</tr>
									</thead>
									<tbody>
									<?php
                               $pdtid=array();
                               $sql = "SELECT * FROM products WHERE id IN(";
			                   foreach($_SESSION['cart'] as $id => $value){
			                   $sql .=$id. ",";
			                   }
			                   $sql=substr($sql,0,-1) . ") ORDER BY id ASC";
			                   $query = mysqli_query($conn,$sql);
			                   $totalprice=0;
							   $totalqunty=0;
							   $shippingcharges=0;
							   $sub=0;
							 
			                   if(!empty($query)){
			                   while($row = mysqli_fetch_array($query)){
							   $quantity=$_SESSION['cart'][$row['id']]['quantity'];

				               $subtotal= $_SESSION['cart'][$row['id']]['quantity']*$row['productprice']+$row['shippingcharges'];
				               $totalprice += $subtotal;
							   $_SESSION['qnty']=$totalqunty+=$quantity;	   
							   $sub+= $_SESSION['cart'][$row['id']]['quantity']*$row['productprice'];
							   $shippingcharges += $row['shippingcharges'];
							   
				               array_push($pdtid,$row['id']);
	                           ?>

										<tr>
											<td class="td-text">
												<div class="order-dsc">
												<p><a href="product-details.php?pid=<?php echo htmlentities($pd=$row['id']);?>" ><?php echo $row['productname'];
												$_SESSION['sid']=$pd;
												?>
												</p>
												</div>
											</td>
											<td>
											<?php echo $_SESSION['cart'][$row['id']]['quantity']; ?>
							                </td>
											
											<td>
											<span class="cart-grand-total-price"><?php echo "Rs"." ".($_SESSION['cart'][$row['id']]['quantity']*$row['productprice']+$row['shippingcharges']); ?>.00</span>
											</td>
										</tr>
										<?php } }
                                    $_SESSION['pid']=$pdtid;
				                    ?>
									</tbody>
								</table>
							</div>	
										</div>
									</div>
									<div class="single-input p-bottom50 clearfix">
									<div class="order-btn">
								<a class="btn-style" href="cart.php">Go Back To Cart</a>
							</div>	
									</div>
									<div class="single-input clearfix">
										
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="single-check p-bottom50 clearfix">
						<div class="check-title">
								<h3>Cart Totals</h3>
							</div>
							<div class="subtotal clearfix">
								<p>Cart Subtotal <strong class="floatright"><span>Rs. <?php echo $sub; ?>.00</span></strong></p>
								<p>Shipping Charges<strong class="floatright"><span>Rs. <?php echo $shippingcharges;.00?></span></strong></p>
								<p>Total <strong class="floatright"><span>Rs. <?php echo $_SESSION['tp']="$totalprice". ".00"; ?></span></strong></p>
							</div>
						</div>
						
						
						<!--<div class="single-check p-bottom50">
						<div class="check-title">
								<h3>Coupon Code</h3>
							</div>
							<div class="single-input check-coupon">
								<form action="mail.php" method="post">
									<div class="input-text">
										<input type="text" name="coupon" />
									</div>
									<div class="submit-text">
										<input type="submit" name="submit" value="Submit">
									</div>
								</form>
							</div>
						
						</div>
					    </div>-->
						<form name="payment" method="post" action="checkout.php">
						<div class="single-check p-bottom50">
						    <div class="check-title">
								<h3>Select a payment method</h3>
							</div>
						
						<div class="single-check accordion-one">
							<ul id="accordion" class="panel-group clearfix">
								<li class="panel">
									<div data-toggle="collapse" data-parent="#accordion" data-target="#collapse1">
										<div class="custom-radio radio-in">
											<input id="male" type="radio" name="gender" value="COD" required>
											<label for="male"><span>COD</span></label>
										</div>
									</div>
									<div class="panel-collapse collapse in" id="collapse1">
										<div class="prayment-dsc">
											<p>Payment as to be done to our delivery person at the time of delivery.</p>
											
										</div><br>
										    <div class="single-input check-coupon">
							                      <div class="submit-text" style="margin-left:40px;">
								                  <input type="submit" name="submit" value="Place Order">
							                     </div>	
							                 </div>
									</div>
									
								</li>
								<!--<li class="panel">
									<div data-toggle="collapse" data-parent="#accordion" data-target="#collapse2">
									<div class="custom-radio">
										<input id="female" type="radio" name="gender" value="female">
										<label for="female"><span>Cheque Payment</span></label>
									</div>
									</div>
									<div class="panel-collapse collapse" id="collapse2">
										<div class="prayment-dsc">
											<p>Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.</p>
										</div>
									</div>
								</li>-->
								<li class="panel">
									<div data-toggle="collapse" data-parent="#accordion" data-target="#collapse3">
									<div class="custom-radio">
										<input id="female2" type="radio" name="gender" value="female2">
										<label for="female2"><span>Online Payment</span></label>
									</div>
									</div>
									<div class="panel-collapse collapse" id="collapse3">
										<div class="prayment-dsc">
											<p>Select a Online payment method</p>
											<div class="mayment-card">
												<ul>
													
													<li><a href="paymentform.php?GetID=<?php echo $totalprice; ?>"><img src="img/footer/v6.png" alt="Payment Card" /></a></li>
												</ul>
											</div>
										</div>
									</div>
								</li>
							</ul>
							
						</div>
						</form>	
						</div>
					</div>
						
				</div>
			</div>
				
		</div>
			
		</section>
		<!-- cart page content section end -->
		<!-- footer section start -->
		<footer>
			<div class="footer-logo-text padding-close">
				<div class="container text-center">
					<a href="index.php"><img src="img/log2.png" alt="Logo" /></a>
					<p>Contact Us:   </p>
				<p>	<i class="fa fa-envelope"> </i> happilyhandmadeonlineportal@gmail.com</p>
					
				</div>
			</div>
			<!-- footer top start -->
			
			<!-- footer top end -->
			<!-- footer bottom start -->
			<div class="footer-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="left floatleft">
							<p>Copyright &copy; 2021 By <a href="http://localhost/hh/index.php">HH Stores</a></p>
								
						</div>
						<div class="right mayment-card floatright">
								<ul>
								
									<li>
										<a href="#"><img src="img/footer/v6	.png" alt="Payment Card" /></a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- footer bottom end -->
		</footer>
		<!-- footer section end -->
		
		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.3.min.js"></script>
		<!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
		<!-- camera slider JS -->
        <script src="js/camera.min.js"></script>
		<!-- jquery.easing js -->
        <script src="js/jquery.easing.1.3.js"></script>
		<!-- slick slider js -->
        <script src="js/slick.min.js"></script>
		<!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
		<!-- magnific-popup js -->
        <script src="js/magnific-popup.min.js"></script>
		<!-- countdown js -->
       <!-- <script src="js/countdown.js"></script>-->
		<!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
		<!-- plugins js -->
        <script src="js/plugins.js"></script>
		<!-- main js -->
        <script src="js/main.js"></script>
    </body>
</html>
<?php } ?>