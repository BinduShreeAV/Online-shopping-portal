<?php
session_start();
include('dbconnection.php');

if(strlen($_SESSION['alogin'])== 0)
    {   
header('location:adminlogin.php');
}
else
{

    
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UFT-8">
  <title>HH Stores</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
    <style>
  	   @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');
		 <?php include('adminstyle.css'); ?>   
		 .manage-form{
			 background-color: white;
		 }

         .x{
			 position: absolute;
			 z-index:2;
			 width: 75%;
			 height: 40px;
			 background:#fafafa;
			 text-align: center;
			 border-collapse: collapse;
			 border-spacing: 0;
			 border-radius: 12px 12px 0 0;
			 overflow: hidden;
			 

         }

         th,td{
			 padding: 7px 13px;
		 }

		 th{
			 background: orange;
			 color: #fafafa;
			 font-size: 17px;
		 }

		 tr:nth-child(odd){
			 background-color: #eeeeee;
		 }
		 
		
  </style>
</head>
<body>
	<div class="sidebar">
		<div class="sidebar-brand">
		<a href="adminhome.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
		</div>
		<br>
		<div class="sidebar-menu">
			<ul>
				<li>
					<a href="adminhome.php"><span class="fas fa-igloo"></span>
						<span>Dashboard</span></a>
				</li>
				<li>
					<a href="addproducts.php" ><span class="fas fa-plus-square"></span>
						<span>Add Products</span></a>
				</li>
				
				<li>
					<a href="manageproducts.php"><span class="fas fa-cogs"></span>
						<span>Manage Products</span></a>
				</li>
				<li>
					<a href="viewcustomers.php" class="active"><span class="fas fa-users"></span>
						<span>View Customers</span></a>
				</li>
				<li>
					<a href="viewfeedbacks.php"><span class="fas fa-comments"></span>
						<span>View Feedbacks</span></a>
				</li>
				<li class="item">
					<a href="" class="order-btn"><span class="fas fa-tasks"></span>
						<span>Order Management <i class="fas fa-chevron-down drop-down"></i></span></a>
						<ul class="sub-menu">
                        <li>
                        <a href="todays-order.php"><span class="fas fa-clipboard-list"></span>
						<span>Today's Order</span></a>   
                        </li>
                        <li>
                        <a href="pending-orders.php"><span class="fas fa-clock"></span>
						<span>Pending Orders</span></a>   
						</li>
						
						<li>
						<a href="outfordelivery-orders.php"><span class="fas fa-clipboard-check"></span>
						<span>Out For Delivery Orders</span></a>   
                        </li>
                        
                        <li>
                        <a href="delivered-orders.php"><span class="fas fa-clipboard-check"></span>
						<span>Delivered Orders</span></a>   
                        </li>
                        </ul>                    
				</li>
				<li>
					<a href="logout1.php"><span class="fas fa-sign-out-alt"></span>
						<span>Sign Out</span></a>
				</li>
			</ul>
		</div>
	</div>
	<div class="main-content">
		<header>
			<h2>
				View Customers
			</h2>
			<div>
				
                <a class="user-wrapper" href="adminhome.php"><span class="fas fa-user-shield"></span>
						<span><h3>Admin</h3></span></a>

			</div>
		</header>
	
<main>
<form id="viewcustomers" class="manage-form" method="post" action="viewcustomers.php">
   <table class="x">
   <tr>
   <th>Id</th>
   <th>Name</th>
   <th>Email</th>
   <th>Contact No</th>
   <th>Shipping Address/City/State/Pincode</th>
   <th>Reg. Date</th>
   </tr>
 
 <tbody>
   <?php $query=mysqli_query($conn,"SELECT * FROM user");
$cnt=1;
while($row=mysqli_fetch_array($query))
{
?>	
<tr>
											<td><?php echo htmlentities($cnt);?></td>
											<td><?php echo htmlentities($row['name']);?></td>
											<td><?php echo htmlentities($row['email_id']);?></td>
											<td> <?php echo htmlentities($row['mobile_no']);?></td>
											<td><?php echo htmlentities($row['shippingaddress'].",".$row['shippingcity'].",".$row['shippingstate']."-".$row['shippingpincode']);?></td>
											<td><?php echo htmlentities($row['regdate']);?></td>
											
										<?php $cnt=$cnt+1; } ?>
										

</tbody>
   


   
</table>
</form>
</main>
</div>
</body>
</html>
<?php } ?>