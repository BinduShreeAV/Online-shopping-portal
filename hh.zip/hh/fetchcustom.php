<?php
session_start();

include('dbconnection.php');



$pname=$_POST['value'];

$sql = "SELECT id  FROM products WHERE productname ='$pname'";

$result = mysqli_query($conn,$sql);
$array = mysqli_fetch_array($result); 


echo json_encode($array);

?>