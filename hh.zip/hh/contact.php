<?php
session_start();
//error_reporting(0);
include('dbconnection.php');

$userid="";
$name1="";
$email="";
$message1="";
if(isset($_POST['submit'])){
if(strlen($_SESSION['login'])==0)
    header('location:login.php');
else
{
	$name1 = isset($_POST['name1'])? $_POST['name1']:' ';
	$message1 = isset($_POST['message1'])? $_POST['message1']:' ';
	
	if(empty($name1)){array_push($errors,"Name is required.");}
	if(empty($message1)){array_push($errors,"Message is required.");}
	
	if(count($errors) == 0)
	 {
    echo "yes";
	$q = "INSERT INTO feedback (userid,name1,email,message1) 
    VALUES('".$_SESSION['id']."','$name1','".$_SESSION['login']."','$message1')";
   
	 	mysqli_query($conn,$q); 
    
   
		 echo "<script type='text/javascript'> alert('Your feedback has been submitted successfully.'); </script>";
		 echo "<script type='text/javascript'> alert('Thank you for providing your valuable feedback.  Wait for the approval.'); </script>";
     
     echo "<script type='text/javascript'> document.location = 'contact.php'; </script>";
    
	 }
}
}
?>


<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Contact || HH Stores</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- favicon -->
        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
		<!-- all css here -->
		<!-- style css -->
		<link rel="stylesheet" href="style.css">
		<!-- modernizr js -->   
    	 <script src="js/vendor/modernizr-2.8.3.min.js"></script>


<!-- Cutomer review slider style-->
<style>

		* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}

/* Slideshow container */
.slideshow-container {
  position: relative;
  background: #f1f1f1f1;
}

/* Slides */
.mySlides {
  display: none;
  padding: 80px;
  text-align: center;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  margin-top: -30px;
  padding: 16px;
  color: #888;
  font-weight: bold;
  font-size: 20px;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  position: absolute;
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
  color: white;
}

/* The dot/bullet/indicator container */
.dot-container {
    text-align: center;
    padding: 20px;
    background: #ddd;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

/* Add a background color to the active dot/circle */
.active, .dot:hover {
  background-color: #717171;
}

/* Add an italic font style to all quotes */
q {font-style: italic;}

/* Add a blue color to the author */
.author {color: cornflowerblue;}
</style>

    </head>
    <body>
       <!-- header section start -->
		<header>
			<div class="header-top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="left floatleft">
							<ul>
	<?php 
	if(isset($_SESSION['login']))
	{   ?>
	<li>
	<i class="icon fa fa-user"></i>
	<a href="#" style="color:white;"><b>Welcome <?php echo htmlentities($_SESSION['username']);?></b></a>
	</li>
	<?php } ?>								
	<li>
	<i class="fa fa-user"></i> 
	<a href="my-account.php"><b>Account</b></a>
	</li>
	<li>
	<i class="icon fa fa-heart"></i>
	<a href="wishlist.php"><b>Wishlist</b></a>
	</li>
	<?php
	if(isset($_SESSION['login'] ) == 0)
	{?>
    <li>
	<i class="icon fa fa-sign-in"></i>
	<a href="login.php"><b>Login</b></a>
    </li>
	<?php }
    else{ ?>
	<li>
	<i class="icon fa fa-sign-out"></i>
	<a href="logout.php"><b>Logout</b></a>
    </li>
	<?php } ?>		 

	</ul>
							
</div>
							
                            
						</div>
					</div>
				</div>
			</div>
			<div id="sticky-menu" class="header-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 header-bottom-bg">
							<div class="logo floatleft">
								<a href="index.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
							</div>
							<div class="mainmenu text-center floatleft">
								<nav>
									<ul>
										<li><a href="index.php">Home</a></li>
										<li>
											<a href="shop.php">products</a>
										</li>
										<li><a href="#">Pages</a>
											<ul>
												
												<li>
													<a href="my-account.php">My account</a>
												</li>
												<li>
													<a href="wishlist.php">Wishlist</a>
												</li>
												<li>
													<a href="shop.php">Contact</a>
												</li>
												
											</ul>
										</li>
										<li>
											<a href="contact.php">contact</a>
										</li>
									</ul>
								</nav>
							</div>
							<!-- mobile menu start -->
							
							<!-- mobile menu end -->
							<?php include('cart-content.php');?>
						</div>
					</div>
				</div>
			</div>
		</header>
        <!-- header section end -->
		<!-- page banner area start -->
		<div class="page-banner">
			<img src="img/slider/333.jpg" alt="Page Banner" />
		</div>
		<!-- page banner area end -->
		<!-- contact area start -->
		<div class="map-contact clearfix">
			<div class="googleMap-info">
				<div class="" id=""></div>
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.4384196031897!2d77.56710561434501!3d12.943773990874117!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae15f33b2b19c1%3A0xec31d6480aa9cfca!2sBMS%20College%20for%20Women!5e0!3m2!1sen!2sin!4v1626099835401!5m2!1sen!2sin" width="1280" height="520" style="border:0;" allowfullscreen="" loading="lazy"></iframe><div class="container">
					<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="main-contact-info">
								<ul class="contact-info">
									<li><h3>contact info</h3></li>
									<li>
										<i class="fa fa-map-marker"></i>
										<div class="text">
										    <p>Bugle Rock Rd, Gandhi Bazaar, </p>
										    <p> Basavanagudi, Bengaluru,</p>
						                    <p> Karnataka 560004</p>
											</div>
									</li>
								
									<li>
										<i class="fa fa-phone"></i>
										<div class="text">
											<p>+91-80-26601836</p>
											<p>+91-80-26607833</p>
										</div>
									</li>
									<li>
										<i class="fa fa-paper-plane-o"></i>
										<div class="text">
											<p></p>
											<p>happilyhandmadeonlineportal@gmail.com</p>
										</div>
									</li>
									
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- contact-informaion start -->
		<div class="contact-informaion section-padding-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="informaion-text">
							<h3>Who we are</h3>
							<p>We are <b>Happily Handmade Store</b>: One stop online shopping site to shop wide varieties of handmade products.</p>
							<p>We sell products that are 100% handmade, with good quality materials, unique designs, and long lasting materials.</p>
							<p>A perfect shopping site to gift your loved ones with the gifts that are handmade.</p>
							</div>
					</div>
					<div class="col-sm-6">
						<div class="row">
							<div class="contact-form clearfix">
								
								<form action="contact.php" method="post">
								<div class="col-sm-6">
								<h3>Feedback</h3>
								</div><br/><br/>
								<?php
	                                if(isset($_SESSION['login'] ) == 0)
	                             {?>
									<div class="col-sm-6">
										<div class="input-text">
											<input type="text" name="name1" placeholder="Your Name" required />
										</div>
									</div>
									
								 <div class="col-sm-6">
										<div class="input-text">
											<input type="text" name="email" value="" placeholder="Email"/>
										</div>
									</div>
									
									<?php }
                                     else{ ?>
									 
									 <div class="col-sm-6">
										<div class="input-text">
											<input type="text" name="name1" value="<?php echo htmlentities($_SESSION['username']);?>" placeholder="Your Name" readonly />
										</div>
									</div>
									 
									<div class="col-sm-6">
										<div class="input-text">
											<input type="text" name="email" value="<?php echo htmlentities($_SESSION['login']);?>" placeholder="Email" readonly/>
										</div>
									</div>
									<?php } ?>	
									<div class="col-xs-12">
										<div class="input-text">
											<textarea name="message1" placeholder="Message" rows="4" required></textarea>
										</div>
									</div>
									<div class="col-xs-12">
										<div class="submit-text">
											<input type="submit" name="submit" value="submit" />
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
<br>

<!-- Code for customer reviews slider-->
<br>
<br>
<br>
<br>
<div class="col-sm-6" style="margin-left:53px;">
<h3><b>Customer Reviews</b></h3>
</div>
<br>
<br>


<div class="slideshow-container">
<?php
 $query=mysqli_query($conn,"SELECT * from feedback where feedbackstatus='Active'");
        while($row=mysqli_fetch_array($query))
             {
            ?>
<div class="mySlides">
  <q><?php echo $row['message1'];?></q>
  <p class="author">- <?php echo $row['name1'];?></p>
</div>
<?php } ?>
<a class="prev" onclick="plusSlides(-1)">❮</a>
<a class="next" onclick="plusSlides(1)">❯</a>
</div>


<br>
<br>
<br>
<br>
<br>
<br>


		<!-- contact-informaion end -->
		<!-- footer section start -->
		<footer>
			<!-- contact area end -->
			<div class="footer-logo-text">
				<div class="container text-center">
				<a href="index.php">
									<img src="img/log2.png" alt="Rideo" />
								</a>
					<p>Contact Us:   </p>
				<p>	<i class="fa fa-envelope"> </i> happilyhandmadeonlineportal@gmail.com</p>
					</div>
			</div>
			<!-- footer top start -->
			
			<!-- footer top end -->
			<!-- footer bottom start -->
			<div class="footer-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="left floatleft">
							<p>Copyright &copy; 2021 By <a href="http://localhost/hh/index.php">HH Stores</a></p>
							</div>
							<div class="right mayment-card floatright">
								<ul>
									
									<li>
										<a href="#"><img src="img/footer/v6.png" alt="Payment Card" /></a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- footer bottom end -->
		</footer>
		<!-- footer section end -->
		
		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.3.min.js"></script>
		<!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
		<!-- camera slider JS -->
        <script src="js/camera.min.js"></script>
		<!-- jquery.easing js -->
        <script src="js/jquery.easing.1.3.js"></script>
		<!-- slick slider js -->
        <script src="js/slick.min.js"></script>
		<!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
		<!-- magnific-popup js -->
        <script src="js/magnific-popup.min.js"></script>
		<!-- countdown js -->
        <!--<script src="js/countdown.js"></script>-->
		<!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
		<!-- plugins js -->
        <script src="js/plugins.js"></script>
		<!-- main js -->
        <script src="js/main.js"></script>
		
		<!-- Google Map JS -->
		<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA_Agsvf36du-7l_mp8iu1a-rXoKcWfs2I"> </script>
		<!-- Custom map-script js -->
        <script src="js/map-script.js"></script>
<!-- for customer review slider-->
		<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>




    </body>
</html>
