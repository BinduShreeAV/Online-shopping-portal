<?php
include('dbconnection.php');

$v=$_POST['var'];
$inactive = "UPDATE feedback SET feedbackstatus='Inactive' WHERE id = '$v'";
if(mysqli_query($conn,$inactive))
{
    echo"<script>alert('Successfully Updated');</script>";
    echo "<script>window.location.href='viewfeedbacks.php'</script>";
}
else{
    echo "<script>alert('something went wrong');</script>".mysqli_error($conn);
}
mysqli_close($conn);


?>
