<?php
session_start();
include('dbconnection.php');
error_reporting(0);

                               $pdtid=array();
                               $sql = "SELECT * FROM products WHERE id IN(";
			                   foreach($_SESSION['cart'] as $id => $value){
			                   $sql .=$id. ",";
			                   }
			                   $sql=substr($sql,0,-1) . ") ORDER BY id ASC";
			                   $query = mysqli_query($conn,$sql);
			                   $totalprice=0;
			                   $totalqunty=0;
							   $totalprice = $_GET['GetID'];
			                   if(!empty($query)){
			                   while($row = mysqli_fetch_array($query)){
				               $quantity=$_SESSION['cart'][$row['id']]['quantity'];
				               $subtotal= $_SESSION['cart'][$row['id']]['quantity']*$row['productprice']+$row['shippingcharges'];
							   
				               //$totalprice += $subtotal;
				               $_SESSION['qnty']=$totalqunty+=$quantity;
							   
							   
							   
				               array_push($pdtid,$row['id']);
	                           }
							   }
							   ?>
							   
							
							   <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Form</title>
<!-- style css -->
<link rel="stylesheet" href="style.css">
	
		
    <style>
      .paylogo{
          margin-left: 1000px;
          margin-top: -100px;

    }
    .backarrow{
        margin-left:180px; 
        margin-top: 35px; 

    }
    .payform{
            position: relative;
            background: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px;
            transition: 0.5s;
    }
    .payform h2{
            font-size: 20px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-align: center;
            
            color: #555;
        }
        .payform input{
            
            padding: 10px;
            background: #f5f5f5;
            color: black;
            border: none;
            outline: none;
            box-shadow: none;
            font-size: 14px;
            
            margin: 15px 0px ;
            letter-spacing: 1px;
            font-weight: 500;
            border: 1px solid #000;
            width: 100%;
        }
        .payform input[type="submit"]{
            max-width: 100px;
            background: #24487f;
            color: #fff;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            letter-spacing: 1px;
            transition: 0.5s;
        }
            .payform input[type="submit"]:hover{
			background-color: rgba(38, 166, 91, 1);
			color: white;
			font-weight:500;
		}	
        section{
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            transition: 0.5%;
        }
        section .container{
            position: relative;
            width: 400px;
            height: 320px;
            background: #fff;
            box-shadow: 0 0 5px 3px black;
            overflow: hidden;
        }

    </style>


</head>
<body>
<header>
			<div class="header-top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="left floatleft">
								<ul>
								<?php 
								if(isset($_SESSION['login']))
                                {   ?>
				                <li>
								<i class="icon fa fa-user"></i>
								<a href="#" style="color:white;"><b>Welcome <?php echo htmlentities($_SESSION['username']);?></b></a>
								</li>
								<?php } ?>								
								</ul>
							</div>		
						</div>
					</div>
				</div>
			</div>
			
        </header>
        <div class="backarrow">
        <a href="javascript:history.back()" style="color:black;font-size:60px;"><span class="fa fa-arrow-left"></span></a>
         </div>                   
        <div class="paylogo">
		<img src="img/log2.png" alt="Logo" />
      </div>
      <section>
      <div class="container">
      <div class="payform">
    <form action="pay.php" method="post">
	<h2>RAZOR PAY</h2>
     <input type="textbox" placeholder="User Name" name="name" id="name" required value="<?php echo htmlentities($_SESSION['username']);?>" readonly><br>

         <input type="text" name="totalprice" value="<?php echo $totalprice; ?>" readonly><br>
     
        <input type="submit" name="submit" value="Proceed">
						
</form>
</div>
           
    </div>
 </section>
</body>
</html>