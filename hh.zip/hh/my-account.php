<?php
session_start();
include('dbconnection.php');

if(strlen($_SESSION['login'])==0)
    {   
header('location:login.php');
}
else{
	if(isset($_POST['submit']))
	{
		$name=$_POST['name'];
		$mobile_no=$_POST['mobile_no'];
		$query=mysqli_query($conn,"UPDATE user set name='$name',mobile_no='$mobile_no' where user_id='".$_SESSION['id']."'");
		if($query)
		{
echo "<script>alert('Your information has been updated');</script>";
		}
	}


?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>My account || HH Stores</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- favicon -->
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <!-- Place favicon.ico in the root directory -->
	<!-- all css here -->
	<!-- style css -->
	<link rel="stylesheet" href="style.css">
	<!-- modernizr js -->
	<script src="js/vendor/modernizr-2.8.3.min.js"></script>
	
	<style>
		.am{
			color: black;
		}

		</style>
</head>

<body>        
    <!-- header section start -->
	<header>
	<div class="header-top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="left floatleft">
							<ul>
								<?php 
								if(isset($_SESSION['login']))
                                {   ?>
				                <li>
								<i class="icon fa fa-user"></i>
								<a href="#" style="color:white;"><b>Welcome <?php echo htmlentities($_SESSION['username']);?></b></a>
								</li>
				                <?php } ?>


								    <li>
										<i class="fa fa-user"></i> 
										<a href="my-account.php"><b>Account</b></a>
									</li>
									<li>
									<i class="icon fa fa-heart"></i>
									<a href="wishlist.php"><b>Wishlist</b></a>
	                             	</li>
									<?php
									if(isset($_SESSION['login'] ) == 0)
									{?>
                                    <li>
									<i class="icon fa fa-sign-in"></i>
									<a href="login.php"><b>Login</b></a></li>
									<?php }
                                    else{ ?>
				                    <li>
									<i class="icon fa fa-sign-out"></i>
									<a href="logout.php"><b>Logout</b></a></li>
				                    <?php } ?>	

								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div id="sticky-menu" class="header-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 header-bottom-bg">
							<div class="logo floatleft">
								<a href="index.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
							</div>
							<div class="mainmenu text-center floatleft">
								<nav>
									<ul>
										<li><a href="index.php">Home</a></li>
										<li>
											<a href="shop.php">products</a>
										</li>
										
										<li><a href="#">Pages</a>
											<ul>
												
												<li>
													<a href="my-account.php">My account</a>
												</li>
												
												<li>
													<a href="wishlist.php">Wishlist</a>
												</li>
												<li>
													<a href="shop.php">Shop</a>
												</li>												
													
											</ul>
										</li>
										<li>
											<a href="contact.php">contact</a>
										</li>
									</ul>
								</nav>
							</div>
							<!-- mobile menu start -->
							
							<!-- mobile menu end -->
							<?php include('cart-content.php');?>
						</div>
					</div>
				</div>
			</div>
		</header>
        <!-- header section end -->
		<!-- page banner area start -->
		<div class="page-banner">
			<img src="img/slider/333.jpg" alt="Page Banner" />
		</div>
		<!-- page banner area end -->
		<!-- my account page content section start -->
		<section class="account-page section-padding">
			<div class="container">
				<div class="account-title">
					<h3>My Account</h3>
				</div>
				<div class="row">
					<div class="col-sm-6">
						<div class="single-check m-bottom50">
							<div class="row">
							<form action="my-account.php" method="post">
							<?php
                            $query=mysqli_query($conn,"SELECT * from user where user_id='".$_SESSION['id']."'");
                            while($row=mysqli_fetch_array($query))
                            {
                            ?>
									<div class="single-input clearfix">
										<div class="col-xs-12">
											<div class="check-title">
												<h3>Your personal information</h3>
												<p>Please be sure to update your personal information if it has changed</p>
											</div>
										</div>
										<div class="col-xs-12">
											<label>Your Full Name:</label>
											<div class="input-text">
												<input type="text" name="name" value="<?php echo $row['name'];?>" required/>
											</div>
										</div>
										<div class="col-xs-12">
											<label>Email:</label>
											<div class="input-text">
												<input type="email" class="form-control unicase-form-control text-input" value="<?php echo $row['email_id'];?>"  readonly />
											</div>
										</div>
										
										<div class="col-xs-12">
											<label>Contact Number:</label>
											<div class="input-text">
												<input type="text" pattern="[0-9]{10}"  title="Input a 10 digit valid number" name="mobile_no" value="<?php echo $row['mobile_no'];?>" required/>
											</div>
										</div>
										<div class="col-xs-12">
											<div class="submit-text">
												<input type="submit" name="submit" value="Save">
											</div>
										</div>
									</div>
								
								<?php } ?>
							</div>
						</div>
						<div class="single-check responsive">
						<h3>Your Feedbacks:</h3>
						<?php
                            $query=mysqli_query($conn,"SELECT * from feedback where userid='".$_SESSION['id']."'");
                            while($row=mysqli_fetch_array($query))
                            {
                            ?>
							<div class="order-history check-title">
								
								<p><?php echo $row['feedbackdate'];?></p>
								<p><i><?php echo $row['message1'];?></i></p><br>
							</div>
							<?php } ?>
						</div>
				     </div>
					</form>



					
				<div class="col-sm-6">
				<h3>Order history</h3>
					<div class="single-check m-bottom50">
					
					   <div class="row">
					       <div class="single-check">
						   <div class="check-title order-history">
								  
								  <p>Here are the orders you've placed since your account was created.</p>
								  <table class="spacing-table text-center">
								<thead>
									<tr>
										<th>Order Date</th>
										<th>Total Amount</th>
										<th>Order Details</th>
										<th>Track</th>
										
									</tr>
								</thead>
								  
						       <?php
								$result = mysqli_query($conn, "SELECT DISTINCT orderdate, amount_paid FROM orders WHERE userid='".$_SESSION['id']."'");
								
								while($row=mysqli_fetch_array($result))
								{?>
							  
														
								<tbody>
								
									<tr>
										
										
									    <td style="padding:1px;"><span class="cart-sub-total-price"><?php echo $row['orderdate']; ?></span></td>
										<td><span class="cart-sub-total-price"><?php echo $row['amount_paid']; ?></span></td>
										<td><a class="am" href="order-history.php?id=<?php echo $row['orderdate'];?>"><b>View</b></a></td>
										<td><a class="am" href="track-order.php?id=<?php echo $row['orderdate'];?>"><b>Track</b></a></td>
										
									</tr>
									
									
									
								
								</tbody>
								<?}?>	
								
							</table>
							
							    </div>
						   </div>
						   
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- my account page content section end -->
		<!-- footer section start -->
		<footer>
			<div class="footer-logo-text padding-close">
				<div class="container text-center">
				<a href="index.php">
									<img src="img/log2.png" alt="Rideo" />
								</a>
					<p>Contact Us:   </p>
				<p>	<i class="fa fa-envelope"> </i> happilyhandmadeonlineportal@gmail.com</p>
					
					
			</div>
			</div>
			<!-- footer top start -->
			
			<!-- footer top end -->
			<!-- footer bottom start -->
			<div class="footer-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
						<div class="left floatleft">
								<p>Copyright &copy; 2021 By <a href="http://localhost/hh/index.php">HH Stores</a></p>
							</div>
							<div class="right mayment-card floatright">
								<ul>
									
									<li>
										<a href="#"><img src="img/footer/v6.png" alt="Payment Card" /></a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- footer bottom end -->
		</footer>
		<!-- footer section end -->
		
		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.3.min.js"></script>
		<!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
		<!-- camera slider JS -->
        <script src="js/camera.min.js"></script>
		<!-- jquery.easing js -->
        <script src="js/jquery.easing.1.3.js"></script>
		<!-- slick slider js -->
        <script src="js/slick.min.js"></script>
		<!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
		<!-- magnific-popup js -->
        <script src="js/magnific-popup.min.js"></script>
		<!-- countdown js -->
      <!--  <script src="js/countdown.js"></script>-->
		<!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
		<!-- plugins js -->
        <script src="js/plugins.js"></script>
		<!-- main js -->
        <script src="js/main.js"></script>
    </body>
</html>
<?php } ?>