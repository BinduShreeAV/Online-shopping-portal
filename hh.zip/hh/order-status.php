<?php
session_start();
include('dbconnection.php');


$oid=$_GET['id'];
 
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UFT-8">
  <title>HH Stores</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
    <style>
  	   @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');
		 <?php include('adminstyle.css'); ?>   
		
		
         .p9-box{
			margin-top: 25px; 
			
		 }
		 .add-box{
			 color:white;
			 background-color: #2b88d8;
			 font-weight: 600;
			 letter-spacing: 2px;
			 font-size:15px;
			 box-shadow: 6px 6px 10px -1px rgba(0,0,0,0.50),
						-6px -6px 10px -1px rgba(255,255,255,0.90);
						
			 border: none;
			 height: 40px;
			 width: 200px;
			 border-radius: 4px;
		 }
		 .add-box:hover{
			box-shadow: inset 4px 4px 6px -1px rgba(0,0,0,0.2),
						inset -4px -4px 6px -1px rgba(255,255,255,0.7),
						-0.5px -0.5px 0px rgba(255,255,255,1),
						0.5px  0.5px 0px rgba(0,0,0,0.15),
						0px 12px 10px -10px rgba(0,0,0,0.05);

						border: 1px solid rgba(0,0,0,0.01);
						
   
         }
         .form1-box{
			color:#8390A2;
			font-weight:600;
			margin-top: 40px;
			font-size: 17px;
		 }
		 .cat-box{
			 line-height: 40px;
             padding: 0 84.5px;	 	 
		 }
  </style>
</head>
<body>
	<div class="sidebar">
		<div class="sidebar-brand">
		<a href="adminhome.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
		</div>
		<br>
		<div class="sidebar-menu">
			<ul>
				<li>
					<a href="adminhome.php"><span class="fas fa-igloo"></span>
						<span>Dashboard</span></a>
				</li>
				<li>
					<a href="addproducts.php" ><span class="fas fa-plus-square"></span>
						<span>Add Products</span></a>
				</li>
				
				<li>
					<a href="manageproducts.php"><span class="fas fa-cogs"></span>
						<span>Manage Products</span></a>
				</li>
				<li>
					<a href="viewcustomers.php"><span class="fas fa-users"></span>
						<span>View Customers</span></a>
				</li>
				<li>
					<a href="viewfeedbacks.php"><span class="fas fa-comments"></span>
						<span>View Feedbacks</span></a>
				</li>
				<li class="item" >
                
					<a href="" class="order-btn" ><span class="fas fa-tasks"></span>
						<span >Order Management <i class="fas fa-chevron-down drop-down"></i></span></a>
						<ul class="sub-menu">
                        <li>
                        <a href="todays-order.php"><span class="fas fa-clipboard-list"></span>
						<span>Today's Order</span></a>   
                        </li>
                        <li>
                        <a href="pending-orders.php"><span class="fas fa-clock"></span>
						<span>Pending Orders</span></a>   
                        </li>
                        <li>
                        <a href="delivered-orders.php"><span class="fas fa-clipboard-check"></span>
						<span>Delivered Orders</span></a>   
                        </li>
                        </ul>                    
				</li>
				<li>
					<a href="logout1.php"><span class="fas fa-sign-out-alt"></span>
						<span>Sign Out</span></a>
				</li>
			</ul>
		</div>
	</div>
	<div class="main-content">
		<header>
			<h2>
				Order Status
			</h2>
			<div>
				
                <a class="user-wrapper" href="adminhome.php"><span class="fas fa-user-shield"></span>
						<span><h3>Admin</h3></span></a>

			</div>
		</header>
	
<main>
<form class="manage-form" method="post" action="action.php">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
     
<?php
     $ret = mysqli_query($conn,"SELECT DISTINCT orderstatus FROM orders WHERE orderdate='$oid' ");
     while($row=mysqli_fetch_array($ret))
     {
     ?>
     <tr>
     <td><div class="form1-box">
	    <label for="Order Status">Order Status</label><br>
		<select  class="cat-box" name="orderstatus"  required>
             <option value="<?php echo htmlentities($row['orderstatus']);?>"><?php echo htmlentities($row['orderstatus']);?></option>
             <option value="Pending">Pending</option>
             <option value="Out For Delivery">Out For Delivery</option>
             <option value="Delivered">Delivered</option>
	</div></td>
    
     </tr>
     
<?php } ?>
<?php
     $ret = mysqli_query($conn,"SELECT DISTINCT orderdate FROM orders WHERE orderdate='$oid' ");
     while($row=mysqli_fetch_array($ret))
     {
     ?>
<tr>
<td>
	<div class="p9-box">
		<input id="updateproducts" name="submit" type="submit" value="UPDATE" class="add-box" required/>
		<input type="hidden" name="oid1" value="<?php echo htmlentities($row['orderdate']);?>"/>
	</div>
	</td>
</tr>
<?php } ?>

     </table>
</form>
</main>
</div>
</body>
</html>