<div class="mainmenu text-center floatleft">
								<nav>
									<ul>
										<li><a href="index.php">Home</a></li>
										<li>
											<a href="shop.php">products</a>
										</li>
										
										<li><a href="#">Pages</a>
											<ul>
												
												<li>
													<a href="my-account.php">My account</a>
												</li>
												<li>
													<a href="checkout.html">CheckOut</a>
												</li>
												<li>
													<a href="wishlist.php">Wishlist</a>
												</li>
												<li>
													<a href="cart.html">Cart</a>
												</li>
												
												<li>
													<a href="shop.php">Shop</a>
												</li>												
													
											</ul>
										</li>
										
									</ul>
								</nav>
							</div>