<div class="cart-menu-area floatright">
							<!--	<ul>
									<li><a href="#"><i class="pe-7s-shopbag"></i> <span>0</span></a>
										<ul class="cart-menu">
											<li>
												<a href="cart.html"><img src="img/cart/1.png" alt="" /></a>
												<div class="cart-menu-title">
													<a href="cart.html"><h5>Mount POW C058 FG </h5></a>
													<span>1 x $2500</span>
												</div>
												<span class="cancel-item"><i class="fa fa-close"></i></span>
											</li>
											<li>
												<a href="cart.html"><img src="img/cart/1.png" alt="" /></a>
												<div class="cart-menu-title">
													<a href="cart.html"><h5>Mount POW C058 FG </h5></a>
													<span>1 x $2500</span>
												</div>
												<span class="cancel-item"><i class="fa fa-close"></i></span>
											</li>
											<li class="cart-menu-btn">
												<a href="cart.html">view cart</a>
												<a href="checkout.html">checkout</a>
											</li>
										</ul>
									</li>
								</ul>-->
							</div>