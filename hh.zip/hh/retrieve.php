<?php

include('dbconnection.php');
session_start();

if(isset($_POST['submit'])){
 
$category=$_POST['category'];
$productname=$_POST['productname'];
$productowner=$_POST['productowner'];
$productprice=$_POST['productprice'];
$productdescription=$_POST['productdescription'];
$productimage=addslashes(file_get_contents($_FILES["productimage"]["tmp_name"]));
$shippingcharges=$_POST['shippingcharges'];
$productquantity=$_POST['productquantity'];
$productstatus=$_POST['productstatus'];
$productavailability=$_POST['productavailability'];


$pd=$_POST['pid'];

$query="UPDATE products SET  category='$category', productname='$productname', productowner='$productowner', productprice='$productprice', productdescription='$productdescription', productimage='$productimage', productstatus='$productstatus',productavailability='$productavailability'
WHERE id='$pd'";

$f=mysqli_query($conn,$query);

if($f){

  echo "<script type='text/javascript'> alert('Product updated successfully'); </script>";
     
     echo "<script type='text/javascript'> document.location = 'manageproducts.php'; </script>";


}
}

?>