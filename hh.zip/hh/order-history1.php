<?php
session_start();
//error_reporting(0);
include('dbconnection.php');
$oid=$_GET['id'];
?>




<!doctype html>
<html class="no-js" lang="en">
    <head>
    
        <title>HH Stores</title>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
    <style>
  	   @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');
		 <?php include('adminstyle.css'); ?>   
        

         .x{
			 position: absolute;
			 z-index:2;
			 width: 75%;
			 height: 40px;
			 background:#fafafa;
			 text-align: center;
			 border-collapse: collapse;
			 border-spacing: 0;
			 border-radius: 12px 12px 0 0;
			 overflow: hidden;
			 

         }

         th,td{
			 padding: 7px 13px;
		 }

		 th{
			 background: orange;
			 color: #fafafa;
			 font-size: 17px;
		 }

		 tr:nth-child(odd){
			 background-color: #eeeeee;
         }
         .am{
            background-color:#2b88d8;
			 color: white;
			 border: none;
			 letter-spacing: 1.5px;	 
			 padding:  4px;
			 
         }
         .am:hover{
			background-color: rgba(38, 166, 91, 1);
			color: white;
			font-weight:500;
		}	
		</style>
    </head>
    <body>
    <div class="sidebar">
		<div class="sidebar-brand">
		<a href="adminhome.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
		</div>
		<br>
		<div class="sidebar-menu">
			<ul>
				<li>
					<a href="adminhome.php"><span class="fas fa-igloo"></span>
						<span>Dashboard</span></a>
				</li>
				<li>
					<a href="addproducts.php" ><span class="fas fa-plus-square"></span>
						<span>Add Products</span></a>
				</li>
				
				<li>
					<a href="manageproducts.php"><span class="fas fa-cogs"></span>
						<span>Manage Products</span></a>
				</li>
				<li>
					<a href="viewcustomers.php"><span class="fas fa-users"></span>
						<span>View Customers</span></a>
				</li>
				<li>
					<a href="viewfeedbacks.php"><span class="fas fa-comments"></span>
						<span>View Feedbacks</span></a>
				</li>
				<li class="item" >
                
					<a href="" class="order-btn" ><span class="fas fa-tasks"></span>
						<span >Order Management <i class="fas fa-chevron-down drop-down"></i></span></a>
						<ul class="sub-menu">
                        <li>
                        <a href="todays-order.php"><span class="fas fa-clipboard-list"></span>
						<span>Today's Order</span></a>   
                        </li>
                        <li>
                        <a href="pending-orders.php"><span class="fas fa-clock"></span>
						<span>Pending Orders</span></a>   
                        </li>
                        <li>
                        <a href="delivered-orders.php"><span class="fas fa-clipboard-check"></span>
						<span>Delivered Orders</span></a>   
                        </li>
                        </ul>                    
				</li>
				<li>
					<a href="logout1.php"><span class="fas fa-sign-out-alt"></span>
						<span>Sign Out</span></a>
				</li>
			</ul>
		</div>
	</div>
    <div class="main-content">
		<header>
			<h2>
				Today's Orders
			</h2>
			<div>
				
                <a class="user-wrapper" href="adminhome.php"><span class="fas fa-user-shield"></span>
						<span><h3>Admin</h3></span></a>

			</div>
		</header>
        <main>
		<!-- cart page content section start -->
		<form class="manage-form" method="get" enctype="multipart/form-data" action="order-history1.php">
		
					<div class="col-xs-15">
                      
						<div class="table-responsive table-one margin-minus section-padding-bottom">
						
							<table class="spacing-table text-center" class="x">
								<thead >
									<tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
									<th>Price Per Unit</th>
									<th>Shipping Charges</th>
									
									</tr>
								</thead>

								<tbody>
								<?php
							 // $result =  mysqli_query($conn, "SELECT * FROM orders WHERE orderdate='$oid' AND userid='".$_SESSION['id']."'");
							  $result =  mysqli_query($conn, "SELECT products.productprice as productprice, products.shippingcharges as shippingcharges,products.productimage as productimage,products.productname as productname,orders.amount_paid as amount_paid, orders.quantity as quantity FROM orders JOIN products on products.id=orders.productid WHERE orderdate='$oid' ");
							  
                              while($row=mysqli_fetch_array($result))
								{?>
	                           
									<tr>
                                     
										<td class="td-img text-left"><?php echo'<img src="data:image;base64,'.base64_encode($row['productimage']).'" alt="image" style="width:100px; height:100px;">';?>
										&emsp;<?php echo $row['productname']; ?>
									    </td>
                                        <td><span class="cart-sub-total-price"><?php echo $row['quantity']; ?></span></td>
										<td><span class="cart-sub-total-price"><?php echo $row['productprice']; ?></span></td>
										<td><span class="cart-sub-total-price"><?php echo $row['shippingcharges']; ?></span></td>
									</tr>
									
									
							
								
								</tbody>
							
								<?php } 
				                    ?>	
							</table>
							

						
					</div>
					
				</div>

               <br>
                    <div class="row">
					    <div class="col-sm-4">
                        <?php
                              $result =  mysqli_query($conn, "SELECT DISTINCT amount_paid, paymentmethod FROM orders WHERE orderdate='$oid' ");
                              while($row=mysqli_fetch_array($result))
								{?>
						   <div class="estimate-text responsive">
							   <div class="subtotal clearfix">
								   <p style="font-size: 18px;">Grandtotal: <span class="floatright">Rs. <?php echo $row['amount_paid']; ".00"; ?></span></p>
								   <p style="font-size: 18px;">Payment Mode: <span class="floatright"><?php echo $row['paymentmethod'];  ?></span></p>
								   <div>
									   <br>
								<a class="am" href="javascript:history.back()">Go Back</a>
							</div>	
							   </div>	
                            </div>
                            <?php } 
				                    ?>	
					    </div>
				    </div>
			</div>



				
			</div>
		</section>
		</form>
		</main>
    </body>
</html>

