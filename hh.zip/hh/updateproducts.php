<?php 
include('dbconnection.php');

	$pid=intval($_GET['id']);
	$product = mysqli_query($conn,"SELECT products.*,category.categoryname as catname,category.id as cid from products join category on category.id=products.category where products.id='$pid'");	
$cols = mysqli_fetch_assoc($product);


?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UFT-8">
  <title>HH Stores</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
    <style>
  	   @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');
		 <?php include('adminstyle.css'); ?>    
		 .add-form{
			 background-color: white;
			 padding: 28px;
			 margin: auto;
			 border: 1px solid rgba(0,0,0,0.01);

		 }
		 .form-box{
			 color:#8390A2;
			 font-weight:600;
			 font-size: 17px;
			 
		 }
		.image1-box{
			display: flex;
			justify-content: center;
			background:#f1f5f9;
			height: 75px;
			weight: 75px;
			margin: 0 15px;
			border-radius: 8px;
			align-items: center;
			text-decoration: none;
			box-shadow: 6px 6px 10px -1px rgba(0,0,0,0.15),
			            -6px -6px 10px -1px rgba(255,255,255,0.7);

		}
		.image1-box:hover{
			box-shadow: inset 4px 4px 6px -1px rgba(0,0,0,0.2),
						inset -4px -4px 6px -1px rgba(255,255,255,0.7),
						-0.5px -0.5px 0px rgba(255,255,255,1),
						0.5px  0.5px 0px rgba(0,0,0,0.15),
						0px 12px 10px -10px rgba(0,0,0,0.05);

						border: 1px solid rgba(0,0,0,0.01);

		}
		.image1-box i {
			font-size: 35px;
			color: orange;
			transition: 0.3s;
		}
		.image1-box:hover i{
			font-size: 45px;
		}
		
		 .status-box{
			 line-height: 40px;
			 padding: 0 84px;
		 }
		 .form1-box{
			color:#8390A2;
			font-weight:600;
			margin-top: -30px;
			font-size: 17px;
		 }
		 .cat-box{
			 line-height: 40px;
			 padding: 0 84.5px;	 
		 }
		 .p1-box{
			color:#8390A2;
			font-weight:600;
			font-size: 17px;
			margin-left: 180px;
			margin-top: -30px;
		 }		
		 .p2-box{
			color:#8390A2;
			font-weight:600;
			font-size: 17px;
			margin-top:10px;
		 }
		 .p3-box{
			color:#8390A2;
			font-weight:600;
			font-size: 17px;
			margin-left: 180px;
			margin-top: 10px;
		 }	
		 .p4-box{
			color:#8390A2;
			font-weight:600;
			font-size: 17px;
			margin-top: 20px;
		    
		 }	
		 .p5-box{	
			font-weight:600;
			margin-left: 168px;
			margin-top: 40px;
		 }
		 .upload-box{
			 margin-top: -25px;
			padding: 0 40px;
			
		}
		.p6-box
		{
			color:#8390A2;
			font-weight:600;
			font-size: 17px;
			margin-top: 30px;
		}
		.p7-box
		{
			color:#8390A2;
			font-weight:600;
			font-size: 17px;
			margin-top: 15px;
		}
		.p8-box{
			color:#8390A2;
			font-weight:600;
			font-size: 17px;
			margin-left: 180px;
			margin-top: 7px;
		 }	
		 .p9-box{
			margin-top: 25px; 
			
		 }
		 .add-box{
			 color:white;
			 background-color: #2b88d8;
			 font-weight: 600;
			 letter-spacing: 2px;
			 font-size:15px;
			 box-shadow: 6px 6px 10px -1px rgba(0,0,0,0.50),
						-6px -6px 10px -1px rgba(255,255,255,0.90);
						
			 border: none;
			 height: 40px;
			 width: 200px;
			 border-radius: 4px;
		 }
		 .add-box:hover{
			box-shadow: inset 4px 4px 6px -1px rgba(0,0,0,0.2),
						inset -4px -4px 6px -1px rgba(255,255,255,0.7),
						-0.5px -0.5px 0px rgba(255,255,255,1),
						0.5px  0.5px 0px rgba(0,0,0,0.15),
						0px 12px 10px -10px rgba(0,0,0,0.05);

						border: 1px solid rgba(0,0,0,0.01);
						
   
		 }
  </style>
</head>
<body>
	<div class="sidebar">
		<div class="sidebar-brand">
		<a href="adminhome.php">
									<img src="img/log.png" alt="Rideo" />
								</a>
		</div>
		<br>
		<div class="sidebar-menu">
			<ul>
				<li>
					<a href="adminhome.php"><span class="fas fa-igloo"></span>
						<span>Dashboard</span></a>
				</li>
				<li>
					<a href="addproducts.php" ><span class="fas fa-plus-square"></span>
						<span>Add Products</span></a>
				</li>
				
				<li>
					<a href="manageproducts.php" class="active"><span class="fas fa-cogs"></span>
						<span>Manage Products</span></a>
				</li>
				<li>
					<a href="viewcustomers.php"><span class="fas fa-users"></span>
						<span>View Customers</span></a>
				</li>
				<li>
					<a href="viewfeedbacks.php"><span class="fas fa-comments"></span>
						<span>View Feedbacks</span></a>
				</li>

				<li class="item">
					<a href="" class="order-btn"><span class="fas fa-tasks"></span>
						<span>Order Management <i class="fas fa-chevron-down drop-down"></i></span></a>
						<ul class="sub-menu">
                        <li>
                        <a href="todays-order.php"><span class="fas fa-clipboard-list"></span>
						<span>Today's Order</span></a>   
                        </li>
                        <li>
                        <a href="pending-orders.php"><span class="fas fa-clock"></span>
						<span>Pending Orders</span></a>   
						</li>
						<li>
						<a href="outfordelivery-orders.php"><span class="fas fa-clipboard-check"></span>
						<span>Out For Delivery Orders</span></a>   
                        </li>
                        <li>
                        <a href="delivered-orders.php"><span class="fas fa-clipboard-check"></span>
						<span>Delivered Orders</span></a>   
                        </li>
                        </ul>                    
				</li>
				<li>
					<a href="logout1.php"><span class="fas fa-sign-out-alt"></span>
						<span>Sign Out</span></a>
				</li>
			</ul>
		</div>
	</div>
	<div class="main-content">
		<header>
			<h2>
				Edit Product
			</h2>
			<div>
				
                <a class="user-wrapper" href="adminhome.php"><span class="fas fa-user-shield"></span>
						<span><h3>Admin</h3></span></a>

			</div>
		</header>
	
<main>
<form id="addproduct" class="add-form" method="post" action="retrieve.php" enctype="multipart/form-data">

<table>
   <tr> <td>
    <div class="form1-box">
        <label for="category">Category</label><br>
            <select class="cat-box" name="category" id="category" onChange="getSubcat(this.value);" required>
                      <option value=" <?php echo htmlentities($cols['category']);?> " selected> <?php echo htmlentities($cols['catname']);?> </option>
					  <?php 
					   $conn = mysqli_connect("localhost","root","","portal");
					   if($conn->connect_error)
					   {
						   die("connection failed" .$conn->connect_error);
					   }
					   $sql = "SELECT * FROM category";
					   $result = mysqli_query($conn,$sql);

					   if(mysqli_num_rows($result)>0)
						 while($row = mysqli_fetch_assoc($result))
						 {?>
						 <option value="<?php echo $row['id'];?>"><?php echo $row['categoryname'];?></option>
							 
					<?php	 }
						 echo"</select>";
						 $conn->close();
					   ?>
            </select>
    </div>
</td><td>
	<div class="p1-box">
	    <label for="Product Name">Product Name</label><br>
		<input id="productname" name="productname" value="<?php echo htmlentities($cols['productname']);?>" 
		placeholder="Enter Product Name" type="text" class="name-box" required/>	
    </div>
</td></tr>

<tr><td>
	<div class="p2-box">
	    <label for="Product Owner">Product Owner</label><br>
		<input id="productowner" name="productowner" value="<?php echo htmlentities($cols['productowner']);?>" placeholder="Enter Product Owner" type="text" class="owner-box" required/>
	</div>
</td><td>
	<div class="p3-box">
	    <label for="Product Price">Product Price</label><br>
		<input id="productprice" name="productprice" value="<?php echo htmlentities($cols['productprice']);?>" placeholder="Enter Product Price" type="text" class="price-box" required/>
	</div>
</td></tr>

<tr><td>

	<div class="p4-box">
	    <label for="Product Descriptiom">Product Description</label><br>
		<textarea  name="productdescription"  placeholder="Enter Product Description" rows="3" class="description-box" required><?php echo htmlentities($cols['productdescription']);?>
</textarea>  
	</div>
</td>
<td>
	<div class="p5-box">
            <div class="image2-box">
			<?php echo'<img src="data:image;base64,'.base64_encode($cols['productimage']).'" alt="image" style="width:155px; height:110px;">';?>
                <input id="image" name="productimage" type="file" />                  
        </div>
    </div>
</td>
</tr>

<tr><td>
	<div class="p6-box">
	    <label for="Shipping Charges">Shipping Charges</label><br>
		<input id="shippingcharges" name="shippingcharges" value="<?php echo htmlentities($cols['shippingcharges']);?>" placeholder="Enter Product Shipping Charge" type="text" class="shipping-box" required/>
	</div>
</td>
<td>
	<div class="p8-box">
	    <label for="Product Status">Product Status</label><br>
		<select   name="productstatus"  id="productstatus" class="status-box" required>
             <option value="<?php echo htmlentities($cols['productstatus']);?>"><?php echo htmlentities($cols['productstatus']);?></option>
             <option value="In Stock">In Stock</option>
             <option value="Out of Stock">Out of Stock</option>
	</div>
	
</td>

</tr>
<tr><td>
	<div class="p7-box">
	    <label for="Product Quantity">Product Quantity</label><br>
		<input id="productquantity" name="productquantity" value="<?php echo htmlentities($cols['productquantity']);?>" placeholder="Enter Product Quantity" type="text" class="quantity-box" required/>
	</div>
</td>
<td>
	<div class="p8-box">
	<label for="Product Availability">Product Availability</label><br>
	<select   name="productavailability"  id="productavailability" class="status-box" required>
             <option value="<?php echo htmlentities($cols['productavailability']);?>"><?php echo htmlentities($cols['productavailability']);?></option>
             <option value="Active">Active</option>
             <option value="Inactive">Inactive</option>
    </div>
	</td>

</tr> 

<tr>
<td>
	<div class="p9-box">
		<input id="updateproducts" name="submit" type="submit" value="UPDATE" class="add-box" required/>
		<input type="hidden" name="pid" value="<?php echo htmlentities($cols['id']);?>"/>
	</div>
	</td>
</tr>

</table>
</form>
</main>
</div>
</body>
</html>
